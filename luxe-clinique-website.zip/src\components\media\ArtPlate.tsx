import { Droplet, Flower2, Leaf, MapPin, MessagesSquare, Scan, Sparkles, Waves, Zap } from "lucide-react";
import type { AssetSlot } from "@/content/assets";

const ICONS = {
  laser: Zap,
  skin: Waves,
  face: Sparkles,
  hair: Leaf,
  room: Flower2,
  consult: MessagesSquare,
  product: Droplet,
  map: MapPin,
  drop: Scan,
} as const;

/**
 * Branded art plate shown in an image slot until genuine or licensed
 * photography is supplied (see docs/ASSET_MANIFEST.md). It is decorative and
 * deliberately does not imitate a photograph.
 */
export default function ArtPlate({ motif, className = "", tone = "light" }: { motif: AssetSlot["motif"]; className?: string; tone?: "light" | "burgundy" }) {
  const Icon = ICONS[motif];
  const dark = tone === "burgundy";
  return (
    <div
      aria-hidden
      className={`relative isolate overflow-hidden ${className}`}
      style={{
        background: dark
          ? "radial-gradient(120% 90% at 80% 10%, #9a3a55 0%, #7b1734 45%, #4d0c20 100%)"
          : "radial-gradient(120% 90% at 85% 0%, #f4dfe2 0%, #f7eeeb 45%, #efe4df 100%)",
      }}
    >
      <svg className="absolute inset-0 h-full w-full" viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id={`ap-${motif}-${tone}`} x1="0" x2="1" y1="0" y2="1">
            <stop offset="0" stopColor={dark ? "#ffffff" : "#7B1734"} stopOpacity={dark ? 0.18 : 0.12} />
            <stop offset="1" stopColor={dark ? "#ffffff" : "#B87A89"} stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0, 1, 2, 3, 4].map((i) => (
          <circle key={i} cx="310" cy="40" r={60 + i * 48} fill="none" stroke={`url(#ap-${motif}-${tone})`} strokeWidth="1.2" />
        ))}
        <path d="M-20 240 C 80 200 160 280 260 230 S 380 190 430 220" fill="none" stroke={dark ? "#ffffff" : "#7B1734"} strokeOpacity={dark ? 0.16 : 0.1} strokeWidth="1.5" />
        <path d="M-20 260 C 90 220 170 300 270 250 S 390 210 430 240" fill="none" stroke={dark ? "#ffffff" : "#B87A89"} strokeOpacity={dark ? 0.12 : 0.18} strokeWidth="1" />
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <span
          className={`grid h-16 w-16 place-items-center rounded-full border backdrop-blur-md ${
            dark ? "border-white/25 bg-white/10 text-white" : "border-white/80 bg-white/55 text-burgundy shadow-[0_10px_30px_rgba(123,23,52,0.12)]"
          }`}
        >
          <Icon size={26} strokeWidth={1.4} />
        </span>
      </div>
    </div>
  );
}
