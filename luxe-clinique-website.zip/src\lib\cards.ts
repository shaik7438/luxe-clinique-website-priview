import { assetById, categoryImage } from "@/content/assets";
import { categories, type Treatment } from "@/content/treatments";
import type { TreatmentCardData } from "@/components/ui/GlassTreatmentCard";
import { resolveImage } from "./images";

/**
 * Image lookup order: /public/images/treatment-<slug>.* → category slot → art plate.
 */
export function treatmentImage(t: Treatment) {
  const own = resolveImage(`treatment-${t.slug}`);
  const slot = assetById(categoryImage[t.category])!;
  return {
    src: own ?? resolveImage(slot.id),
    alt: own ? `${t.name} at The LUXE Clinique` : slot.alt,
    motif: slot.motif,
  };
}

export function toCard(t: Treatment): TreatmentCardData {
  const img = treatmentImage(t);
  return {
    slug: t.slug,
    name: t.name,
    summary: t.summary,
    categoryLabel: categories[t.category].label,
    hasModule: !!t.module,
    image: img.src,
    imageAlt: img.alt,
    motif: img.motif,
  };
}
