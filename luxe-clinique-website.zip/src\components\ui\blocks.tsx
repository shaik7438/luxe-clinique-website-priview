import Link from "next/link";
import { ArrowRight, ChevronRight, ShieldAlert } from "lucide-react";
import type { ReactNode } from "react";
import { AnimatedSection, Reveal, StaggerHeadline } from "@/components/motion/AnimatedSection";
import { reviewNotice } from "@/content/site";

export function PageHero({
  eyebrow,
  title,
  intro,
  crumbs,
  children,
}: {
  eyebrow: string;
  title: string;
  intro?: string;
  crumbs?: { href: string; label: string }[];
  children?: ReactNode;
}) {
  return (
    <section className="luxe-canvas grain relative overflow-hidden pb-14 pt-32 sm:pt-36 lg:pb-20">
      <div className="pointer-events-none absolute -right-40 -top-40 h-[34rem] w-[34rem] rounded-full bg-rose/20 blur-3xl" />
      <div className="container-luxe relative">
        {crumbs && <Breadcrumbs items={crumbs} />}
        <p className="eyebrow mt-6">{eyebrow}</p>
        <h1 className="font-display mt-4 max-w-4xl text-[2.35rem] leading-[1.08] text-charcoal sm:text-5xl lg:text-[3.6rem]">
          <StaggerHeadline text={title} />
        </h1>
        {intro && <p className="mt-6 max-w-2xl text-[17px] leading-relaxed text-muted">{intro}</p>}
        {children}
      </div>
    </section>
  );
}

export function Breadcrumbs({ items }: { items: { href: string; label: string }[] }) {
  return (
    <nav aria-label="Breadcrumb">
      <ol className="flex flex-wrap items-center gap-1 text-[13px] text-muted">
        <li>
          <Link href="/" className="hover:text-burgundy">Home</Link>
        </li>
        {items.map((c, i) => (
          <li key={c.href} className="flex items-center gap-1">
            <ChevronRight size={14} aria-hidden />
            {i === items.length - 1 ? (
              <span aria-current="page" className="text-charcoal">{c.label}</span>
            ) : (
              <Link href={c.href} className="hover:text-burgundy">{c.label}</Link>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

export function SectionHeading({ eyebrow, title, intro, align = "left", id }: { eyebrow: string; title: string; intro?: string; align?: "left" | "center"; id?: string }) {
  return (
    <AnimatedSection as="div" className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      <Reveal as="p" className="eyebrow">{eyebrow}</Reveal>
      <Reveal>
        <h2 id={id} className="font-display mt-4 text-[2rem] leading-[1.12] text-charcoal sm:text-[2.6rem]">{title}</h2>
      </Reveal>
      {intro && <Reveal as="p" className="mt-4 text-[16.5px] leading-relaxed text-muted">{intro}</Reveal>}
    </AnimatedSection>
  );
}

export function ConsultationCTA({ title = "Start with a consultation", body }: { title?: string; body?: string }) {
  return (
    <section className="container-luxe section !pt-0">
      <AnimatedSection as="div" className="glass-burgundy glass-sheen relative overflow-hidden px-6 py-12 sm:px-12 lg:py-16">
        <div className="pointer-events-none absolute -right-24 -top-24 h-80 w-80 rounded-full border border-white/10" />
        <div className="pointer-events-none absolute -right-10 -top-10 h-80 w-80 rounded-full border border-white/10" />
        <div className="relative grid items-end gap-8 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <Reveal as="p" className="eyebrow !text-white/70">Appointments</Reveal>
            <Reveal>
              <h2 className="font-display mt-4 text-[2rem] leading-tight sm:text-[2.6rem]">{title}</h2>
            </Reveal>
            <Reveal as="p" className="mt-4 max-w-xl text-[16px] leading-relaxed text-white/80">
              {body ?? "A clinician assesses your concern and discusses suitable options, potential risks, expected limitations, alternatives and aftercare — before any decision is made."}
            </Reveal>
          </div>
          <Reveal className="flex flex-wrap gap-3 lg:justify-end">
            <Link href="/contact#enquiry" className="btn bg-white text-burgundy hover:-translate-y-0.5">
              Book a Consultation <ArrowRight size={16} aria-hidden />
            </Link>
            <Link href="/patient-information" className="btn border border-white/30 text-white hover:bg-white/10">
              What to expect
            </Link>
          </Reveal>
        </div>
      </AnimatedSection>
    </section>
  );
}

export function ReviewNotice({ className = "" }: { className?: string }) {
  return (
    <aside className={`flex gap-3 rounded-2xl border border-line bg-white/70 p-4 text-[13.5px] leading-relaxed text-muted ${className}`}>
      <ShieldAlert size={18} className="mt-0.5 shrink-0 text-burgundy" aria-hidden />
      <p>{reviewNotice}</p>
    </aside>
  );
}
