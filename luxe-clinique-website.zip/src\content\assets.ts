/**
 * Visual asset manifest. Each entry is a slot in the site. Drop a file named
 * `<id>.webp` (or .jpg/.png/.avif) into /public/images and it is used
 * automatically at build time; until then a branded art plate renders.
 *
 * Source rule: genuine clinic photography for staff, rooms and equipment.
 * Licensed stock or AI-generated imagery only for generic, clearly
 * non-identifying scenes — never presented as the clinic's own staff,
 * patients or results. Exported to docs/ASSET_MANIFEST.md.
 */
export type AssetSource = "clinic-photo" | "licensed-or-generated" | "educational-render";

export interface AssetSlot {
  id: string;
  location: string;
  subject: string;
  alt: string;
  source: AssetSource;
  crops: { desktop: string; mobile: string };
  motif: "laser" | "skin" | "face" | "hair" | "room" | "consult" | "product" | "map" | "drop";
}

export const assets: AssetSlot[] = [
  { id: "home-clinic-interior", location: "Home · clinic introduction", subject: "Reception or consultation room at The LUXE Clinique, natural daylight, ivory and burgundy palette, no people.", alt: "Consultation room at The LUXE Clinique in Preet Vihar", source: "clinic-photo", crops: { desktop: "4:5, 1200×1500", mobile: "4:3, 900×675" }, motif: "room" },
  { id: "home-consultation", location: "Home · consultation process", subject: "Clinician and adult patient seated in conversation, reviewing a tablet; faces may be turned away; genuine staff only.", alt: "A clinician discusses treatment options with a patient during a consultation", source: "clinic-photo", crops: { desktop: "3:2, 1500×1000", mobile: "4:3, 900×675" }, motif: "consult" },
  { id: "about-team", location: "About · clinic approach", subject: "Verified clinician(s) in the clinic, with written consent for web use.", alt: "Clinician at The LUXE Clinique (name and registration to be confirmed)", source: "clinic-photo", crops: { desktop: "4:5, 1200×1500", mobile: "1:1, 900×900" }, motif: "consult" },
  { id: "about-room", location: "About · facility", subject: "Treatment room with bed, laser device and lighting; equipment should be the clinic's actual devices.", alt: "Treatment room at The LUXE Clinique", source: "clinic-photo", crops: { desktop: "16:9, 1920×1080", mobile: "4:3, 900×675" }, motif: "room" },
  { id: "cat-laser", location: "Treatments · Laser & energy-based", subject: "Close-up of a laser handpiece with cooling tip resting on a forearm, gloved hand, protective eyewear visible.", alt: "Laser handpiece held against the skin of a forearm by a gloved clinician", source: "licensed-or-generated", crops: { desktop: "4:3, 1200×900", mobile: "4:3, 800×600" }, motif: "laser" },
  { id: "cat-injectables", location: "Treatments · Injectables", subject: "Clinician marking facial points with a cosmetic pencil before treatment; no needle in skin; neutral expression.", alt: "Clinician planning injection points on a patient's face during an assessment", source: "licensed-or-generated", crops: { desktop: "4:3, 1200×900", mobile: "4:3, 800×600" }, motif: "face" },
  { id: "cat-skin", location: "Treatments · Skin rejuvenation", subject: "Hydradermabrasion handpiece on the cheek, soft clinical light, natural skin texture visible.", alt: "Medical facial handpiece used on the cheek", source: "licensed-or-generated", crops: { desktop: "4:3, 1200×900", mobile: "4:3, 800×600" }, motif: "skin" },
  { id: "cat-pigmentation", location: "Treatments · Pigmentation", subject: "Clinician examining facial skin with a magnifying lamp; untouched natural skin texture.", alt: "Clinician examining skin pigmentation under a magnifying lamp", source: "licensed-or-generated", crops: { desktop: "4:3, 1200×900", mobile: "4:3, 800×600" }, motif: "skin" },
  { id: "cat-hair", location: "Treatments · Hair & scalp", subject: "Trichoscope examination of a scalp parting; adult patient seated; no before/after.", alt: "Scalp being examined with a trichoscope", source: "licensed-or-generated", crops: { desktop: "4:3, 1200×900", mobile: "4:3, 800×600" }, motif: "hair" },
  { id: "cat-dermatology", location: "Treatments · Medical dermatology", subject: "Dermatoscope examination of the forearm by a gloved clinician.", alt: "Skin on the forearm being examined with a dermatoscope", source: "licensed-or-generated", crops: { desktop: "4:3, 1200×900", mobile: "4:3, 800×600" }, motif: "skin" },
  { id: "cat-procedures", location: "Treatments · Minor procedures", subject: "Sterile instrument tray and dressing on an ivory surface; no wounds shown.", alt: "Sterile tray prepared for a minor skin procedure", source: "licensed-or-generated", crops: { desktop: "4:3, 1200×900", mobile: "4:3, 800×600" }, motif: "drop" },
  { id: "patient-info", location: "Patient information · hero", subject: "Hands holding a consent form and pen at a consultation desk.", alt: "Patient reviewing an information and consent form", source: "licensed-or-generated", crops: { desktop: "16:9, 1920×1080", mobile: "4:3, 900×675" }, motif: "consult" },
  { id: "products", location: "About · products", subject: "Products from the clinic's shelf (ZO Skin Health, Obagi, Heliocare) photographed in clinic — only if stocked.", alt: "Skincare and sun-protection products available at the clinic", source: "clinic-photo", crops: { desktop: "3:2, 1500×1000", mobile: "1:1, 900×900" }, motif: "product" },
  { id: "contact-exterior", location: "Contact · location", subject: "Building entrance at 103 Rajdhani Enclave with clinic signage, daytime.", alt: "Entrance to The LUXE Clinique at Rajdhani Enclave, Preet Vihar", source: "clinic-photo", crops: { desktop: "3:2, 1500×1000", mobile: "4:3, 900×675" }, motif: "map" },
];

export const assetById = (id: string) => assets.find((a) => a.id === id);

export const categoryImage: Record<string, string> = {
  laser: "cat-laser",
  injectables: "cat-injectables",
  skin: "cat-skin",
  pigmentation: "cat-pigmentation",
  hair: "cat-hair",
  dermatology: "cat-dermatology",
  procedures: "cat-procedures",
};
