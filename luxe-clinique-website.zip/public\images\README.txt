﻿Drop photography here named by asset id (see docs/ASSET_MANIFEST.md), e.g. home-clinic-interior.webp or treatment-laser-hair-reduction.webp. Rebuild to apply.
