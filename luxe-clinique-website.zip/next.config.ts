import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  images: {
    formats: ["image/avif", "image/webp"],
  },
  async redirects() {
    // Preserve the most important legacy WordPress URLs from the current site.
    return [
      { source: "/index.html", destination: "/", permanent: true },
      { source: "/about-us/index.html", destination: "/about", permanent: true },
      { source: "/our-gallery/index.html", destination: "/gallery", permanent: true },
      { source: "/blog/index.html", destination: "/learn", permanent: true },
      { source: "/contact-us/index.html", destination: "/contact", permanent: true },
      { source: "/book-a-visit/index.html", destination: "/contact#enquiry", permanent: true },
      { source: "/privacy-policy/index.html", destination: "/legal/privacy", permanent: true },
      { source: "/treatments/advanced-skincare/index.html", destination: "/treatments/advanced-skincare", permanent: true },
      { source: "/treatments/botox-anti-wrinkle-treatment/index.html", destination: "/treatments/anti-wrinkle-injections", permanent: true },
      { source: "/treatments/dermal-fillers/index.html", destination: "/treatments/dermal-fillers", permanent: true },
      { source: "/treatments/lip-enhancement/index.html", destination: "/treatments/lip-fillers", permanent: true },
      { source: "/treatments/jawline-slimming/index.html", destination: "/treatments/jawline-slimming", permanent: true },
      { source: "/treatments/facial-contouring-profile/index.html", destination: "/treatments/jawline-contouring", permanent: true },
      { source: "/treatments/excessive-sweating-hyperhidrosis/index.html", destination: "/treatments/hyperhidrosis", permanent: true },
      { source: "/treatments/skin-revitalisation-skin-boosters/index.html", destination: "/treatments/skin-boosters", permanent: true },
      { source: "/conditions/acne-and-acne-scarring/index.html", destination: "/treatments/acne-and-acne-scars", permanent: true },
      { source: "/conditions/pigmentation/index.html", destination: "/learn/understanding-pigmentation", permanent: true },
      { source: "/2025/01/23/what-are-dermal-fillers-1/index.html", destination: "/learn/what-are-dermal-fillers", permanent: true },
      { source: "/2025/02/25/are-facial-aesthetic-treatments-suitable-for-people-with-sensitive-skin-1/index.html", destination: "/learn/sensitive-skin-and-aesthetic-treatments", permanent: true },
      { source: "/2024/12/19/how-to-improve-the-shape-of-your-chin-2/index.html", destination: "/learn/understanding-chin-and-profile", permanent: true },
    ];
  },
};

export default nextConfig;
