# The LUXE Clinique — website

A full replacement for luxecliniqueaesthetics.com: a Next.js site with
interactive 3D medical education, a glass UI system and motion design, built
from the supplied content sheet and NMC compliance screening.

**Stack:** Next.js 15 (App Router) · TypeScript · Tailwind CSS v4 · Framer Motion · React Three Fiber / Three.js / Drei · Lucide.

## Run it

Requires Node.js 20+ (installed: v24 LTS).

```bash
npm install
npm run dev          # http://localhost:3000
```

Production preview:

```bash
npm run build
npm start            # http://localhost:3000
```

Copy `.env.example` to `.env.local` to configure:

- `NEXT_PUBLIC_SITE_URL` — canonical URL for metadata, sitemap and JSON-LD.
- `ENQUIRY_WEBHOOK_URL` — where appointment enquiries are POSTed (CRM, Zapier/Make, email relay). In development without it, enquiries are written to `.data/enquiries.ndjson`. In production without it, the form tells visitors honestly that online enquiries aren't connected and offers phone, WhatsApp and email instead.
- `NEXT_PUBLIC_HERO_GLB` — optional production GLB that replaces the procedural hero scene.

## Deploy

Any Node host works; Vercel is the simplest: import the repo, set the env vars above, deploy. All 56 content pages are statically generated; only `/api/enquiry` runs on the server. Legacy WordPress URLs (e.g. `/about-us/index.html`, `/treatments/botox-anti-wrinkle-treatment/index.html`) redirect permanently to their new pages (`next.config.ts`).

## What's here

| Area | Where |
|---|---|
| Brand tokens, glass system, buttons | `src/app/globals.css` |
| Verified clinic facts | `src/content/site.ts` |
| 33 treatment guides + 6 held for review | `src/content/treatments.ts` |
| 3D module definitions (steps, structures, text alternatives) | `src/content/education.ts` |
| Articles | `src/content/articles.ts` |
| Image slots | `src/content/assets.ts` → `docs/ASSET_MANIFEST.md` |
| Hero scene | `src/components/three/HeroScene.tsx`, wrapper `LaserTreatmentHero3D.tsx` |
| Skin cross-section scene | `src/components/three/SkinScene.tsx` |
| Module UI | `src/components/education/Educational3DModule.tsx` (+ `InteractiveSkinModel`, `LaserEducationScene`) |
| Navigation / footer | `src/components/layout/` |
| Directory and detail template | `src/components/treatments/` |
| Enquiry form and API | `src/components/forms/AppointmentForm.tsx`, `src/app/api/enquiry/route.ts` |

### Pages
`/` · `/treatments` (search, category and concern filters, shareable URLs) · `/treatments/[slug]` ×33 · `/learn` · `/learn/[slug]` ×6 · `/learn/models/[id]` ×6 · `/patient-information` · `/about` · `/gallery` · `/contact` · `/legal/privacy` · `/legal/terms` · `/legal/medical-disclaimer` · `sitemap.xml` · `robots.txt`

## 3D: what it is and isn't

- The **hero** is a stylised, procedurally modelled scene (porcelain-style figures, treatment bed, laser console, handpiece in contact with skin, eye protection for both people). It is not a photoreal human render; no realistic human GLB was available. It is labelled on screen as a stylised illustration. Drop in a commissioned GLB via `NEXT_PUBLIC_HERO_GLB` for photorealism.
- The **educational modules** share one parametric skin scene driven by step state (layer separation, hair tone, growth phases, melanin depth, comedone, inflammation, scar depth, collagen density). Each has selectable structures, step sequence, rotate/reset controls, keyboard support (← → R), a static SVG fallback, and a text alternative.
- 3D is code-split and lazy-loaded, paused when off-screen, simplified on touch and small screens, wrapped in an error boundary, and respects `prefers-reduced-motion`. Without WebGL, the static illustrations render instead and every CTA still works.

## Tested

Production build: 64 routes, no type errors. A crawl of all 56 sitemap pages found 0 broken internal links, unique titles, exactly one `h1` per page, meta descriptions on all, and alt attributes on all images. At 375px every page has no horizontal overflow. The mobile menu, directory filters, form validation, honest 503 path, honeypot, legacy redirects and 404 all work. No runtime console errors. Not tested: real iOS/Android devices, Safari, and screen-reader passes. Run those before launch.

## Before launch

See **`docs/APPROVALS.md`**: clinical review of all medical content, verification of phone numbers and hours, legal review of drafts, enquiry destination, and photography.
