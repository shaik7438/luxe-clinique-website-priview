import type { MetadataRoute } from "next";
import { articles } from "@/content/articles";
import { modules } from "@/content/education";
import { site } from "@/content/site";
import { publishedTreatments } from "@/content/treatments";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const staticPaths = ["", "/treatments", "/learn", "/patient-information", "/about", "/gallery", "/contact", "/legal/privacy", "/legal/terms", "/legal/medical-disclaimer"];
  return [
    ...staticPaths.map((p) => ({ url: `${site.url}${p}`, lastModified: now, changeFrequency: "monthly" as const, priority: p === "" ? 1 : 0.7 })),
    ...publishedTreatments.map((t) => ({ url: `${site.url}/treatments/${t.slug}`, lastModified: now, changeFrequency: "monthly" as const, priority: 0.8 })),
    ...articles.map((a) => ({ url: `${site.url}/learn/${a.slug}`, lastModified: new Date(a.updated), changeFrequency: "yearly" as const, priority: 0.6 })),
    ...Object.keys(modules).map((id) => ({ url: `${site.url}/learn/models/${id}`, lastModified: now, changeFrequency: "yearly" as const, priority: 0.5 })),
  ];
}
