# Visual asset manifest — The LUXE Clinique

Source of truth: `src/content/assets.ts`. To fill a slot, save the file as
`public/images/<id>.webp` (or `.jpg`, `.png`, `.avif`) and rebuild — it replaces
the branded art plate automatically. Per-treatment photos can also be added as
`public/images/treatment-<slug>.webp` (e.g. `treatment-laser-hair-reduction.webp`),
which override the category image on cards and treatment pages.

**Rules.** Genuine clinic photography for staff, rooms, equipment and products.
Licensed stock or AI-generated imagery only for generic, non-identifying scenes,
never presented as the clinic's own staff, patients or results. No patient
before/after images or testimonials pending legal review (see `APPROVALS.md`).
Grading: warm neutral white balance, soft diffused light, ivory and burgundy
accents, natural (unretouched) skin texture. Export WebP at ~80 quality, max
1920px on the long edge.

## Photography slots

| ID | Location | Subject / shot brief | Alt text | Source | Desktop crop | Mobile crop |
|---|---|---|---|---|---|---|
| home-clinic-interior | Home · introduction | Reception or consultation room, daylight, no people | Consultation room at The LUXE Clinique in Preet Vihar | Clinic photo | 4:5 1200×1500 | 4:3 900×675 |
| home-consultation | Home · consultation process | Clinician and adult patient seated in conversation reviewing a tablet; genuine staff only | A clinician discusses treatment options with a patient during a consultation | Clinic photo | 3:2 1500×1000 | 4:3 900×675 |
| about-team | About · clinicians | Verified clinician(s) in clinic, written consent | Clinician at The LUXE Clinique (name and registration to be confirmed) | Clinic photo | 4:5 1200×1500 | 1:1 900×900 |
| about-room | About · facility | Treatment room with bed and the clinic's actual laser device | Treatment room at The LUXE Clinique | Clinic photo | 16:9 1920×1080 | 4:3 900×675 |
| products | About · products | Products on the clinic shelf (ZO Skin Health, Obagi, Heliocare), only if stocked | Skincare and sun-protection products available at the clinic | Clinic photo | 3:2 1500×1000 | 1:1 900×900 |
| contact-exterior | Contact / About · location | Building entrance at 103 Rajdhani Enclave with signage, daytime | Entrance to The LUXE Clinique at Rajdhani Enclave, Preet Vihar | Clinic photo | 3:2 1500×1000 | 4:3 900×675 |
| cat-laser | Laser & energy-based cards | Laser handpiece with cooling tip on a forearm, gloved hand, eyewear visible | Laser handpiece held against the skin of a forearm by a gloved clinician | Licensed / generated | 4:3 1200×900 | 4:3 800×600 |
| cat-injectables | Injectables cards | Clinician marking facial points with cosmetic pencil; no needle in skin | Clinician planning injection points on a patient's face during an assessment | Licensed / generated | 4:3 1200×900 | 4:3 800×600 |
| cat-skin | Skin rejuvenation cards | Hydradermabrasion handpiece on cheek, natural texture | Medical facial handpiece used on the cheek | Licensed / generated | 4:3 1200×900 | 4:3 800×600 |
| cat-pigmentation | Pigmentation cards | Clinician examining facial skin with magnifying lamp | Clinician examining skin pigmentation under a magnifying lamp | Licensed / generated | 4:3 1200×900 | 4:3 800×600 |
| cat-hair | Hair & scalp cards | Trichoscope examination of a scalp parting | Scalp being examined with a trichoscope | Licensed / generated | 4:3 1200×900 | 4:3 800×600 |
| cat-dermatology | Medical dermatology cards | Dermatoscope examination of the forearm | Skin on the forearm being examined with a dermatoscope | Licensed / generated | 4:3 1200×900 | 4:3 800×600 |
| cat-procedures | Minor procedures cards | Sterile instrument tray on ivory surface; no wounds | Sterile tray prepared for a minor skin procedure | Licensed / generated | 4:3 1200×900 | 4:3 800×600 |
| patient-info | Patient information | Hands holding a consent form and pen at a desk | Patient reviewing an information and consent form | Licensed / generated | 16:9 1920×1080 | 4:3 900×675 |

## 3D and educational assets (built, in the codebase)

| Asset | File | Type | Used on | Notes |
|---|---|---|---|---|
| Laser treatment hero scene | `src/components/three/HeroScene.tsx` | Procedural R3F scene (no external files) | Home hero | Stylised "porcelain" figures; patient eye shields, clinician safety glasses, handpiece in skin contact, no visible beam. Labelled "Stylised 3D illustration · not a real patient or clinician". |
| Hero static poster | `src/components/three/HeroPoster.tsx` | Inline SVG | Hero loading/no-WebGL fallback, Gallery | Instant paint; same composition. |
| Skin cross-section (6 modules) | `src/components/three/SkinScene.tsx` + `src/content/education.ts` | Procedural R3F, state-driven | Home, Learn, treatment pages, `/learn/models/*` | Modules: skin, laser, pigment, acne, collagen, hair. |
| Skin illustration | `src/components/education/SkinIllustration.tsx` | State-aware inline SVG | 3D fallback, article cards, Gallery, treatment hero | Mirrors every module step. |
| Optional production hero GLB | `NEXT_PUBLIC_HERO_GLB` | GLB (not supplied) | Home hero | Commission a realistic scene from a 3D artist; Draco/Meshopt-compressed, KTX2 textures, < 3 MB. Loaded via `useGLTF` when set. |
| Logo | `public/brand/luxe-clinique-logo.png`, `luxe-mark.png` | PNG cropped from the supplied JPEG | Nav, footer, favicon | Ask for a vector (SVG) master for sharper rendering. |
