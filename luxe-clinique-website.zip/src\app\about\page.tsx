import Link from "next/link";
import { BookOpen, MapPin, ShieldCheck, Stethoscope } from "lucide-react";
import ClinicImage from "@/components/media/ClinicImage";
import { AnimatedSection, MaskReveal, Reveal } from "@/components/motion/AnimatedSection";
import { ConsultationCTA, PageHero, SectionHeading } from "@/components/ui/blocks";
import { site } from "@/content/site";
import { pageMeta } from "@/lib/seo";

export const metadata = pageMeta({
  title: "About the Clinic",
  description: "About The LUXE Clinique in Preet Vihar, New Delhi: our consultation-first approach, patient education, services and location.",
  path: "/about",
});

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About the clinic"
        title="Consultation-led skin, hair and aesthetic care"
        intro="The LUXE Clinique offers consultations on skin, hair, laser and aesthetic concerns in Preet Vihar, New Delhi — with an emphasis on clear information, comfort and individual care."
        crumbs={[{ href: "/about", label: "About" }]}
      />

      <section className="container-luxe pb-10" aria-labelledby="approach">
        <div className="grid items-center gap-12 lg:grid-cols-12">
          <MaskReveal className="lg:col-span-5">
            <ClinicImage id="about-room" className="aspect-[4/5] w-full rounded-[28px]" priority />
          </MaskReveal>
          <div className="lg:col-span-7">
            <SectionHeading
              id="approach"
              eyebrow="Our approach"
              title="Assessment, information, then a decision that's yours"
              intro="A clinician assesses each person's concerns and discusses suitable options, benefits, risks, alternatives and aftercare. Treatment plans are personalised to individual skin needs, with emphasis on evidence-based care, comfort and safety."
            />
            <AnimatedSection as="ul" className="mt-8 grid gap-4 sm:grid-cols-3">
              {[
                { icon: Stethoscope, t: "Clinical assessment", b: "Every plan starts with understanding your skin and history." },
                { icon: BookOpen, t: "Patient education", b: "Plain-language explanations and 3D guides." },
                { icon: ShieldCheck, t: "Responsible care", b: "Risks and limitations discussed openly." },
              ].map(({ icon: Icon, t, b }) => (
                <Reveal as="li" key={t} className="glass p-5">
                  <Icon size={20} className="text-burgundy" aria-hidden />
                  <h3 className="mt-3 font-semibold">{t}</h3>
                  <p className="mt-1 text-[14px] leading-relaxed text-muted">{b}</p>
                </Reveal>
              ))}
            </AnimatedSection>
          </div>
        </div>
      </section>

      <section className="section container-luxe" aria-labelledby="team">
        <div className="grid items-center gap-12 lg:grid-cols-12">
          <div className="order-2 lg:order-1 lg:col-span-7">
            <SectionHeading id="team" eyebrow="Clinicians" title="The people caring for you" />
            <div className="glass mt-8 p-6">
              <p className="text-[15px] leading-relaxed text-muted">
                Clinician profiles — including names, qualifications and medical council registration numbers — will be published here once verified by the clinic. We only list credentials that have been confirmed.
              </p>
              <p className="mt-4 text-[13px] font-semibold uppercase tracking-[0.14em] text-rose-ink">Pending clinic verification</p>
            </div>
          </div>
          <MaskReveal className="order-1 lg:order-2 lg:col-span-5">
            <ClinicImage id="about-team" className="aspect-square w-full rounded-[28px]" />
          </MaskReveal>
        </div>
      </section>

      <section className="section !pt-0 container-luxe" aria-labelledby="products">
        <div className="glass grid items-center gap-10 overflow-hidden p-6 sm:p-10 lg:grid-cols-2">
          <div>
            <p className="eyebrow">Skincare products</p>
            <h2 id="products" className="font-display mt-4 text-[2rem] leading-tight">Product guidance, only where suitable</h2>
            <p className="mt-4 text-[15.5px] leading-relaxed text-muted">
              The clinic&apos;s product range includes skincare from brands such as {site.products.slice(0, 2).join(" and ")}, and {site.products[2]} sun protection. Products are discussed during consultation for individual skin needs; buying products is never a condition of care.
            </p>
          </div>
          <ClinicImage id="products" className="aspect-[3/2] w-full rounded-[22px]" />
        </div>
      </section>

      <section className="section !pt-0 container-luxe" aria-labelledby="where">
        <div className="grid gap-8 lg:grid-cols-2">
          <div>
            <p className="eyebrow">Location</p>
            <h2 id="where" className="font-display mt-4 text-[2rem]">Preet Vihar, New Delhi</h2>
            <p className="mt-4 flex gap-2 text-[15.5px] text-charcoal">
              <MapPin size={18} className="mt-1 shrink-0 text-burgundy" aria-hidden />
              {site.address.line1}, {site.address.locality}, {site.address.city} {site.address.postalCode}
            </p>
            <p className="mt-3 text-[15px] leading-relaxed text-muted">{site.directions}</p>
            <Link href="/contact" className="btn btn-glass mt-6">Contact & directions</Link>
          </div>
          <ClinicImage id="contact-exterior" className="aspect-[3/2] w-full rounded-[28px]" />
        </div>
      </section>

      <ConsultationCTA />
    </>
  );
}
