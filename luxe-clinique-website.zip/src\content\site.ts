/**
 * Verified-from-source facts only. Every value here comes from the supplied
 * content sheet (Luxe_Clinique_Website_Content_One_Sheet.xlsx). Items marked
 * `verify` are flagged in docs/APPROVALS.md and must be confirmed by the
 * clinic before launch.
 */
export const site = {
  name: "The LUXE Clinique",
  shortName: "Luxe Clinique",
  tagline: "Skin · Hair · Laser · Wellness",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.luxecliniqueaesthetics.com",
  description:
    "The LUXE Clinique, Preet Vihar, New Delhi — consultations and education on skin, hair, laser and aesthetic treatments, with options discussed after individual clinical assessment.",
  address: {
    line1: "103, Rajdhani Enclave",
    locality: "Preet Vihar",
    city: "New Delhi",
    postalCode: "110092",
    region: "Delhi",
    country: "IN",
  },
  // Source sheet: both numbers appear on different pages — VERIFY before publishing.
  phones: [
    { display: "+91 89202 19690", tel: "+918920219690", verify: true },
    { display: "+91 88828 33050", tel: "+918882833050", verify: true },
  ],
  whatsapp: "918920219690", // assumed same as primary — VERIFY
  email: "luxecliniqueaesthetics@gmail.com",
  directions:
    "Near Preet Vihar Metro Station (Gate No. 3). Nearby areas include Laxmi Nagar, Nirman Vihar, IP Extension, Karkardooma and Anand Vihar. Please check the route on Google Maps and call ahead about parking.",
  mapsUrl: "https://www.google.com/maps/search/?api=1&query=103+Rajdhani+Enclave+Preet+Vihar+New+Delhi+110092",
  hours: null as null | string, // Not in the source content — supply before launch.
  products: ["ZO Skin Health", "Obagi", "Heliocare"],
  heroModelUrl: process.env.NEXT_PUBLIC_HERO_GLB || "",
} as const;

export const nav = [
  { href: "/treatments", label: "Treatments" },
  { href: "/learn", label: "Learn" },
  { href: "/patient-information", label: "Patient Information" },
  { href: "/about", label: "About" },
  { href: "/gallery", label: "Gallery" },
  { href: "/contact", label: "Contact" },
] as const;

export const reviewNotice =
  "Educational information only. It does not replace a consultation, diagnosis or individual medical advice. Suitability, risks and expected results vary between individuals and are discussed with a qualified clinician.";
