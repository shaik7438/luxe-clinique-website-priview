import { notFound } from "next/navigation";
import TreatmentDetailLayout from "@/components/treatments/TreatmentDetailLayout";
import { getTreatment, publishedTreatments } from "@/content/treatments";
import { site } from "@/content/site";
import { toCard, treatmentImage } from "@/lib/cards";
import { JsonLd, pageMeta } from "@/lib/seo";

export function generateStaticParams() {
  return publishedTreatments.map((t) => ({ slug: t.slug }));
}

export const dynamicParams = false;

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const t = getTreatment(slug);
  if (!t) return {};
  return pageMeta({ title: `${t.name} — How It Works, Risks & Aftercare`, description: t.summary.slice(0, 158), path: `/treatments/${t.slug}` });
}

export default async function TreatmentPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const t = getTreatment(slug);
  if (!t) notFound();

  const related = publishedTreatments
    .filter((r) => r.slug !== t.slug && (r.category === t.category || r.concerns.some((c) => t.concerns.includes(c))))
    .slice(0, 3)
    .map(toCard);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "MedicalWebPage",
    name: t.name,
    description: t.summary,
    url: `${site.url}/treatments/${t.slug}`,
    about: { "@type": "MedicalProcedure", name: t.name },
    publisher: { "@type": "MedicalClinic", name: site.name, url: site.url },
  };

  return (
    <>
      <TreatmentDetailLayout t={t} image={treatmentImage(t)} related={related} />
      <script type="application/ld+json" dangerouslySetInnerHTML={JsonLd({ data: jsonLd })} />
    </>
  );
}
