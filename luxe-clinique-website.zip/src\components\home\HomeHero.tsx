"use client";

import Link from "next/link";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, ArrowRight, MapPin } from "lucide-react";
import { useRef } from "react";
import LaserTreatmentHero3D from "@/components/three/LaserTreatmentHero3D";
import { StaggerHeadline, EASE } from "@/components/motion/AnimatedSection";

export default function HomeHero() {
  const ref = useRef<HTMLElement>(null);
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const visualY = useTransform(scrollYProgress, [0, 1], [0, reduced ? 0 : 90]);
  const textY = useTransform(scrollYProgress, [0, 1], [0, reduced ? 0 : 40]);
  const fade = useTransform(scrollYProgress, [0, 0.8], [1, reduced ? 1 : 0.35]);

  const enter = (delay: number) => ({
    initial: reduced ? false : ({ opacity: 0, y: 18 } as const),
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.9, delay, ease: EASE },
  });

  return (
    <section ref={ref} className="luxe-canvas grain relative overflow-hidden pb-16 pt-28 sm:pt-32 lg:min-h-[100svh] lg:pb-24 lg:pt-36">
      <div className="pointer-events-none absolute -left-32 top-24 h-[28rem] w-[28rem] rounded-full bg-burgundy/[0.06] blur-3xl" />
      <div className="pointer-events-none absolute -right-20 -top-28 h-[36rem] w-[36rem] rounded-full bg-rose/25 blur-3xl" />

      <div className="container-luxe relative grid items-center gap-10 lg:grid-cols-12 lg:gap-8">
        <motion.div style={{ y: textY, opacity: fade }} className="lg:col-span-5">
          <motion.p {...enter(0.05)} className="eyebrow">
            Personalised aesthetic care
          </motion.p>
          <h1 className="font-display mt-5 text-[2.6rem] leading-[1.04] tracking-[-0.01em] text-charcoal sm:text-[3.4rem] lg:text-[3.85rem]">
            <StaggerHeadline text="Advanced Treatments." delay={0.15} />{" "}
            <span className="text-burgundy">
              <StaggerHeadline text="Informed Skin Decisions." delay={0.45} />
            </span>
          </h1>
          <motion.p {...enter(0.8)} className="mt-6 max-w-[34rem] text-[17px] leading-relaxed text-muted">
            Explore aesthetic and skin-care treatments through clear education, professional consultation, and individualised care.
          </motion.p>
          <motion.div {...enter(0.95)} className="mt-8 flex flex-wrap gap-3">
            <Link href="/contact#enquiry" className="btn btn-primary">
              Book a Consultation <ArrowRight size={16} aria-hidden />
            </Link>
            <Link href="/treatments" className="btn btn-glass">
              Explore Treatments
            </Link>
          </motion.div>
          <motion.p {...enter(1.1)} className="mt-8 flex items-center gap-2 text-[13.5px] text-muted">
            <MapPin size={15} className="text-burgundy" aria-hidden /> Preet Vihar, New Delhi · Skin · Hair · Laser · Wellness
          </motion.p>
        </motion.div>

        <motion.div style={{ y: visualY }} className="lg:col-span-7">
          <LaserTreatmentHero3D />
        </motion.div>
      </div>

      <motion.a
        href="#introduction"
        {...enter(1.6)}
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 items-center gap-2 rounded-full px-3 py-2 text-[12px] font-medium uppercase tracking-[0.18em] text-muted hover:text-burgundy lg:flex"
      >
        Scroll <ArrowDown size={14} className={reduced ? "" : "animate-bounce"} aria-hidden />
      </motion.a>
    </section>
  );
}
