"use client";

/**
 * Procedural skin cross-section used by every educational module.
 * One parametric scene (SkinState) drives skin anatomy, laser, pigmentation,
 * acne, collagen and hair-cycle sequences. Conceptual, not to scale.
 */

import { createContext, useContext, useEffect, useMemo, useRef } from "react";
import { Canvas, useFrame, useThree, type ThreeEvent } from "@react-three/fiber";
import { Html, OrbitControls } from "@react-three/drei";
import * as THREE from "three";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import type { SkinState, StructureId } from "@/content/education";
import { structures as structureInfo } from "@/content/education";
import { seeded, Tube } from "./primitives";

const W = 3.2; // block width (x)
const D = 1.3; // block depth (z), front face at z = 0
const EPI = [0.8, 0.95] as const;
const DERM = [-0.2, 0.8] as const;
const SUB = [-1.0, -0.2] as const;
const FOLLICLES = [-1.0, -0.4, 0.2, 0.85];
const SCAR_X = 0.52;

type Phase = "anagen" | "catagen" | "telogen";

interface Ctx {
  selected: StructureId | null;
  select: (id: StructureId) => void;
  labels: Set<StructureId>;
  showLabels: boolean;
}
const SceneCtx = createContext<Ctx>({ selected: null, select: () => {}, labels: new Set(), showLabels: true });

/* ─────────── Helpers ─────────── */

function useHighlight(id: StructureId, base: string, opts: THREE.MeshPhysicalMaterialParameters = {}) {
  const { selected } = useContext(SceneCtx);
  const mat = useMemo(() => new THREE.MeshPhysicalMaterial({ color: base, roughness: 0.6, ...opts }), [base]); // eslint-disable-line react-hooks/exhaustive-deps
  useFrame(() => {
    const target = selected === id ? 0.35 : 0;
    mat.emissive.set("#7B1734");
    mat.emissiveIntensity += (target - mat.emissiveIntensity) * 0.15;
  });
  return mat;
}

function usePick(id: StructureId) {
  const { select } = useContext(SceneCtx);
  return {
    onClick: (e: ThreeEvent<MouseEvent>) => {
      e.stopPropagation();
      select(id);
    },
    onPointerOver: (e: ThreeEvent<PointerEvent>) => {
      e.stopPropagation();
      document.body.style.cursor = "pointer";
    },
    onPointerOut: () => {
      document.body.style.cursor = "";
    },
  };
}

function Label({ id, position, side = "right" }: { id: StructureId; position: [number, number, number]; side?: "left" | "right" }) {
  const { selected, select, labels, showLabels } = useContext(SceneCtx);
  if (!showLabels || !labels.has(id)) return null;
  const active = selected === id;
  return (
    <Html position={position} zIndexRange={[20, 0]} style={{ pointerEvents: "none" }}>
      <button
        type="button"
        tabIndex={-1}
        onClick={() => select(id)}
        style={{ pointerEvents: "auto", transform: side === "left" ? "translate(-100%, -50%)" : "translate(0, -50%)" }}
        className={`flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-1 text-[11px] font-semibold shadow-sm backdrop-blur-md transition-colors ${
          active ? "border-burgundy bg-burgundy text-white" : "border-white/80 bg-white/75 text-charcoal hover:bg-white"
        } ${side === "left" ? "flex-row-reverse" : ""}`}
      >
        <span className={`h-1.5 w-1.5 rounded-full ${active ? "bg-white" : "bg-burgundy"}`} />
        {structureInfo[id].label}
      </button>
    </Html>
  );
}

/**
 * Slab whose top/bottom edges follow functions of x (for the scar depression),
 * spanning z ∈ [−D, 0]. Built directly from quads because both edges are
 * x-monotone — more robust than triangulating an extruded shape.
 */
function layerGeometry(bottom: (x: number) => number, top: (x: number) => number) {
  const N = 80;
  const v: number[] = [];
  const quad = (a: number[], b: number[], c: number[], d: number[]) => v.push(...a, ...b, ...c, ...a, ...c, ...d);
  for (let i = 0; i < N; i++) {
    const x0 = -W / 2 + (i / N) * W;
    const x1 = -W / 2 + ((i + 1) / N) * W;
    const b0 = bottom(x0), b1 = bottom(x1), t0 = top(x0), t1 = top(x1);
    quad([x0, b0, 0], [x1, b1, 0], [x1, t1, 0], [x0, t0, 0]); // front
    quad([x1, b1, -D], [x0, b0, -D], [x0, t0, -D], [x1, t1, -D]); // back
    quad([x0, t0, 0], [x1, t1, 0], [x1, t1, -D], [x0, t0, -D]); // top
    quad([x1, b1, 0], [x0, b0, 0], [x0, b0, -D], [x1, b1, -D]); // bottom
  }
  const L = -W / 2, R = W / 2;
  quad([L, bottom(L), -D], [L, bottom(L), 0], [L, top(L), 0], [L, top(L), -D]); // left end
  quad([R, bottom(R), 0], [R, bottom(R), -D], [R, top(R), -D], [R, top(R), 0]); // right end
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(v, 3));
  g.computeVertexNormals();
  return g;
}

const dent = (scar: number) => (x: number) => scar * 0.17 * Math.exp(-((x - SCAR_X) ** 2) / (2 * 0.2 ** 2));

/* ─────────── Layers ─────────── */

function Epidermis({ scar, melanin }: { scar: number; melanin: number }) {
  const d = dent(scar);
  const geo = useMemo(() => layerGeometry((x) => EPI[0] - d(x) * 0.8, (x) => EPI[1] - d(x)), [scar]); // eslint-disable-line react-hooks/exhaustive-deps
  const mat = useHighlight("epidermis", "#F0CDB6", { roughness: 0.45, sheen: 0.6, sheenColor: new THREE.Color("#fff1e8"), clearcoat: 0.2 });
  const pick = usePick("epidermis");
  const dots = useMemo(() => {
    const r = seeded(7);
    const n = Math.round(110 * melanin);
    return Array.from({ length: n }, () => {
      const x = -W / 2 + 0.05 + r() * (W - 0.1);
      return [x, EPI[0] + 0.02 + r() * 0.05 - d(x) * 0.8, 0.004 + r() * 0.01] as [number, number, number];
    });
  }, [melanin, scar]); // eslint-disable-line react-hooks/exhaustive-deps
  const melMat = useHighlight("melanin", "#4A2B1D", { roughness: 0.5 });
  const pickMel = usePick("melanin");
  return (
    <group>
      <mesh geometry={geo} material={mat} {...pick} castShadow receiveShadow />
      <Instances positions={dots} radius={0.022} material={melMat} pick={pickMel} />
      <Label id="epidermis" position={[-W / 2 + 0.04, EPI[1] + 0.1, 0.02]} />
      <Label id="melanin" position={[-0.7, EPI[0] + 0.04, 0.02]} />
    </group>
  );
}

function Dermis({ scar, collagen, dermalMelanin }: { scar: number; collagen: number; dermalMelanin: number }) {
  const d = dent(scar);
  const geo = useMemo(() => layerGeometry(() => DERM[0], (x) => DERM[1] - d(x) * 0.8), [scar]); // eslint-disable-line react-hooks/exhaustive-deps
  const mat = useHighlight("dermis", "#E8A9A6", { roughness: 0.7, sheen: 0.4, sheenColor: new THREE.Color("#ffd9d6") });
  const pick = usePick("dermis");

  const fibres = useMemo(() => {
    const r = seeded(11);
    const n = Math.round(46 * collagen);
    return Array.from({ length: n }, () => {
      const x0 = -W / 2 + 0.1 + r() * (W - 1.0);
      const len = 0.5 + r() * 0.8;
      const y0 = DERM[0] + 0.12 + r() * 0.7;
      const z = 0.012 + r() * 0.02;
      const amp = 0.025 + r() * 0.03;
      const pts: [number, number, number][] = [];
      for (let k = 0; k <= 6; k++) {
        const x = Math.min(W / 2 - 0.05, x0 + (k / 6) * len);
        pts.push([x, Math.min(DERM[1] - 0.06 - d(x), y0 + Math.sin(k * 1.4 + x0 * 5) * amp), z]);
      }
      return pts;
    });
  }, [collagen, scar]); // eslint-disable-line react-hooks/exhaustive-deps
  const colMat = useHighlight("collagen", "#FFF4F0", { roughness: 0.35, sheen: 0.5, sheenColor: new THREE.Color("#ffffff") });
  const pickCol = usePick("collagen");

  const deep = useMemo(() => {
    const r = seeded(23);
    const n = Math.round(60 * dermalMelanin);
    return Array.from({ length: n }, () => [-0.3 + r() * 1.5, DERM[1] - 0.12 - r() * 0.4, 0.006 + r() * 0.012] as [number, number, number]);
  }, [dermalMelanin]);
  const melMat = useHighlight("melanin", "#5B3A2A");
  const pickMel = usePick("melanin");

  return (
    <group>
      <mesh geometry={geo} material={mat} {...pick} receiveShadow />
      {fibres.map((pts, i) => (
        <Tube key={i} points={pts} radius={0.011} segments={24} material={colMat} {...pickCol}>
          <primitive object={colMat} attach="material" />
        </Tube>
      ))}
      <Instances positions={deep} radius={0.027} material={melMat} pick={pickMel} />
      <Label id="dermis" position={[-W / 2 + 0.04, 0.62, 0.02]} />
      <Label id="collagen" position={[-0.05, 0.12, 0.04]} />
    </group>
  );
}

function Subcutis() {
  const mat = useHighlight("subcutis", "#F2D7A0", { roughness: 0.55, sheen: 0.4, sheenColor: new THREE.Color("#fff3d6") });
  const lobMat = useHighlight("subcutis", "#F7E4B3", { roughness: 0.35, clearcoat: 0.4 });
  const pick = usePick("subcutis");
  const lobules = useMemo(() => {
    const r = seeded(3);
    const out: [number, number, number][] = [];
    for (let x = -W / 2 + 0.13; x < W / 2 - 0.1; x += 0.23)
      for (let y = SUB[0] + 0.14; y < SUB[1] - 0.08; y += 0.21) out.push([x + (r() - 0.5) * 0.05, y + (r() - 0.5) * 0.04, -0.03]);
    return out;
  }, []);
  return (
    <group>
      <mesh position={[0, (SUB[0] + SUB[1]) / 2, -D / 2]} material={mat} {...pick} receiveShadow>
        <boxGeometry args={[W, SUB[1] - SUB[0], D]} />
      </mesh>
      <Instances positions={lobules} radius={0.11} material={lobMat} pick={pick} />
      <Label id="subcutis" position={[-W / 2 + 0.04, (SUB[0] + SUB[1]) / 2, 0.12]} />
    </group>
  );
}

function Instances({
  positions,
  radius,
  material,
  pick,
}: {
  positions: [number, number, number][];
  radius: number;
  material: THREE.Material;
  pick?: ReturnType<typeof usePick>;
}) {
  const ref = useRef<THREE.InstancedMesh>(null);
  useEffect(() => {
    const m = ref.current;
    if (!m) return;
    const o = new THREE.Object3D();
    positions.forEach((p, i) => {
      o.position.set(...p);
      o.updateMatrix();
      m.setMatrixAt(i, o.matrix);
    });
    m.count = positions.length;
    m.instanceMatrix.needsUpdate = true;
    m.computeBoundingSphere();
  }, [positions]);
  if (!positions.length) return null;
  return (
    <instancedMesh key={positions.length} ref={ref} args={[undefined, undefined, positions.length]} material={material} {...pick}>
      <sphereGeometry args={[radius, 12, 10]} />
    </instancedMesh>
  );
}

/* ─────────── Follicle ─────────── */

const PHASE_GEO: Record<Phase, { len: number; bulb: number }> = {
  anagen: { len: 1.12, bulb: 0.11 },
  catagen: { len: 0.72, bulb: 0.075 },
  telogen: { len: 0.48, bulb: 0.06 },
};

function Follicle({
  x,
  index,
  phase,
  tone,
  state,
  pulseT,
}: {
  x: number;
  index: number;
  phase: Phase;
  tone: "dark" | "light";
  state: SkinState;
  pulseT: React.MutableRefObject<number>;
}) {
  const tilt = 0.22 + (index % 2) * 0.06;
  const { len, bulb } = PHASE_GEO[phase];
  const sheathMat = useHighlight("follicle", "#F3C3B9", { roughness: 0.5, transparent: true, opacity: 0.92 });
  const bulbMat = useHighlight("bulb", tone === "dark" ? "#6B4A3C" : "#D9BE91", { roughness: 0.45 });
  const shaftMat = useHighlight("shaft", tone === "dark" ? "#2A1C17" : "#D8BF8C", { roughness: 0.35, clearcoat: 0.6 });
  const glandMat = useHighlight("sebaceous", "#F4D27A", { roughness: 0.3, clearcoat: 0.5 });
  const pickF = usePick("follicle");
  const pickB = usePick("bulb");
  const pickS = usePick("shaft");
  const pickG = usePick("sebaceous");
  const glow = useRef<THREE.MeshBasicMaterial>(null);

  const absorbs = !!state.pulse && tone === "dark";
  const responsive = absorbs && phase === "anagen";
  const acne = index === 2;
  const gland = (acne ? state.glandScale ?? 1 : 1) * (phase === "telogen" ? 0.85 : 1);

  useFrame(() => {
    if (!glow.current) return;
    const p = pulseT.current; // 0..1 cycle; absorption peaks after the wave reaches the bulb
    const k = responsive ? Math.max(0, Math.sin(Math.min(1, Math.max(0, (p - 0.5) / 0.45)) * Math.PI)) : absorbs ? 0.25 * Math.max(0, Math.sin(p * Math.PI)) : 0;
    glow.current.opacity = Math.min(1, k * 0.95);
  });

  const hideForScar = (state.scar ?? 0) > 0 && Math.abs(x - SCAR_X) < 0.4;
  if (hideForScar) return null;

  return (
    <group position={[x, EPI[1], 0.02]} rotation-z={tilt}>
      {/* Follicle sheath */}
      <mesh position={[0, -len / 2, 0]} material={sheathMat} {...pickF}>
        <cylinderGeometry args={[0.07, 0.085, len, 20, 1, true]} />
      </mesh>
      {/* Bulb */}
      <mesh position={[0, -len, 0]} material={bulbMat} {...pickB} scale={[1, 1.15, 1]}>
        <sphereGeometry args={[bulb, 24, 16]} />
      </mesh>
      {/* Conceptual absorption glow at the bulb */}
      <mesh position={[0, -len, 0]} scale={2.6}>
        <sphereGeometry args={[bulb, 20, 14]} />
        <meshBasicMaterial ref={glow} color="#FF8A50" transparent opacity={0} depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
      </mesh>
      {/* Shaft — runs from bulb through the follicle and out above the surface */}
      <mesh position={[0, (-len + 0.7) / 2, 0]} material={shaftMat} {...pickS}>
        <cylinderGeometry args={[0.02, 0.026, len + 0.7, 10]} />
      </mesh>
      {/* Sebaceous gland */}
      <group position={[0.11, -0.3, 0]} scale={gland}>
        {[
          [0, 0, 0, 0.06],
          [0.06, -0.05, 0.01, 0.05],
          [0.03, -0.1, -0.01, 0.045],
        ].map(([gx, gy, gz, r], i) => (
          <mesh key={i} position={[gx, gy, gz]} material={glandMat} {...pickG}>
            <sphereGeometry args={[r, 16, 12]} />
          </mesh>
        ))}
      </group>
      {/* Acne: plug and inflammation */}
      {acne && state.plug && (
        <mesh position={[0, -0.06, 0]}>
          <sphereGeometry args={[0.085, 18, 14]} />
          <meshStandardMaterial color="#CDB26A" roughness={0.6} />
        </mesh>
      )}
      {acne && state.plug && (
        <mesh position={[0, 0.0, 0]}>
          <sphereGeometry args={[0.05, 14, 10]} />
          <meshStandardMaterial color="#3E3127" roughness={0.6} />
        </mesh>
      )}
      {acne && state.inflammation && <Inflammation />}
      {index === 1 && <Label id="follicle" position={[0.09, -0.55, 0.06]} />}
      {index === 0 && <Label id="shaft" position={[0.03, 0.55, 0.02]} />}
      {index === 3 && phase === "anagen" && <Label id="bulb" position={[0.12, -len, 0.06]} />}
      {index === 1 && <Label id="sebaceous" position={[0.2, -0.32, 0.06]} />}
      {state.phases && (
        <Html position={[-0.08, -len - 0.2, 0.05]} center zIndexRange={[19, 0]} style={{ pointerEvents: "none" }}>
          <span className="whitespace-nowrap rounded-full bg-charcoal/80 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-white">
            {phase}
          </span>
        </Html>
      )}
    </group>
  );
}

function Inflammation() {
  const ref = useRef<THREE.Mesh>(null);
  useFrame(({ clock }) => {
    if (ref.current) ref.current.scale.setScalar(1 + Math.sin(clock.getElapsedTime() * 1.6) * 0.04);
  });
  return (
    <mesh ref={ref} position={[0, -0.38, 0]}>
      <sphereGeometry args={[0.36, 28, 20]} />
      <meshStandardMaterial color="#E0465A" transparent opacity={0.28} depthWrite={false} roughness={0.8} />
    </mesh>
  );
}

/* ─────────── Glands and vessels ─────────── */

function SweatGland() {
  const mat = useHighlight("sweat", "#A9CFDD", { roughness: 0.3, clearcoat: 0.6 });
  const pick = usePick("sweat");
  const duct = useMemo<[number, number, number][]>(
    () => [
      [1.35, -0.18, 0.03],
      [1.3, 0.05, 0.03],
      [1.38, 0.3, 0.03],
      [1.3, 0.55, 0.03],
      [1.36, 0.78, 0.03],
      [1.33, EPI[1] + 0.01, 0.03],
    ],
    [],
  );
  return (
    <group>
      <mesh position={[1.35, -0.3, 0.03]} rotation-x={Math.PI / 2} material={mat} {...pick}>
        <torusKnotGeometry args={[0.085, 0.024, 96, 10, 2, 5]} />
      </mesh>
      <Tube points={duct} radius={0.016} segments={48} material={mat} {...pick}>
        <primitive object={mat} attach="material" />
      </Tube>
      <Label id="sweat" position={[1.48, -0.3, 0.05]} side="left" />
    </group>
  );
}

function Vessels() {
  const art = useHighlight("vessels", "#C8414F", { roughness: 0.3, clearcoat: 0.6 });
  const vein = useHighlight("vessels", "#6A6FB0", { roughness: 0.3, clearcoat: 0.6 });
  const pick = usePick("vessels");
  const path = (y: number, z: number, loops: boolean): [number, number, number][] => {
    const pts: [number, number, number][] = [];
    for (let i = 0; i <= 16; i++) {
      const x = -W / 2 + 0.05 + (i / 16) * (W - 0.1);
      const lift = loops && i % 4 === 2 ? 0.5 : 0;
      pts.push([x, y + Math.sin(i * 0.9) * 0.04 + lift, z]);
    }
    return pts;
  };
  const a = useMemo(() => path(-0.05, 0.035, true), []); // eslint-disable-line react-hooks/exhaustive-deps
  const v = useMemo(() => path(-0.12, 0.05, false), []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <group>
      <Tube points={a} radius={0.026} segments={160} {...pick}>
        <primitive object={art} attach="material" />
      </Tube>
      <Tube points={v} radius={0.03} segments={120} {...pick}>
        <primitive object={vein} attach="material" />
      </Tube>
      <Label id="vessels" position={[0.55, -0.08, 0.06]} />
    </group>
  );
}

/* ─────────── Conceptual light pulse ─────────── */

function PulseWave({ pulseT, active, animate }: { pulseT: React.MutableRefObject<number>; active: boolean; animate: boolean }) {
  const group = useRef<THREE.Group>(null);
  const mats = useRef<THREE.MeshBasicMaterial[]>([]);
  useFrame((_, dt) => {
    pulseT.current = animate ? (pulseT.current + dt / 2.8) % 1 : 0.7;
    if (!group.current) return;
    group.current.visible = active;
    if (!active) return;
    const p = pulseT.current;
    // Wavefronts travel from above the skin down to bulb depth, fading as they go deeper.
    group.current.children.forEach((c, i) => {
      const local = Math.min(1, Math.max(0, (p - i * 0.06) / 0.62));
      c.position.y = 1.65 - local * 1.95;
      const m = mats.current[i];
      if (m) m.opacity = local > 0 && local < 1 ? Math.sin(local * Math.PI) * (0.62 - i * 0.14) * (c.position.y > EPI[1] ? 1 : 0.7) : 0;
    });
  });
  return (
    <group ref={group}>
      {[0, 1, 2].map((i) => (
        // A thin band on the cross-section face, so the wavefront reads clearly from the front.
        <mesh key={i} position={[0, 1.6, 0.09]}>
          <planeGeometry args={[W * 0.98, 0.06 - i * 0.012]} />
          <meshBasicMaterial
            ref={(m) => {
              if (m) mats.current[i] = m;
            }}
            color="#FFB38F"
            transparent
            opacity={0}
            depthWrite={false}
            blending={THREE.AdditiveBlending}
            toneMapped={false}
          />
        </mesh>
      ))}
    </group>
  );
}

/* ─────────── Rig: model rotation, explode, reset ─────────── */

function Model({ state, rotation, animate }: { state: SkinState; rotation: number; animate: boolean }) {
  const root = useRef<THREE.Group>(null);
  const epi = useRef<THREE.Group>(null);
  const sub = useRef<THREE.Group>(null);
  const pulseT = useRef(0);
  const explode = state.explode ?? 0;

  useFrame(() => {
    const k = animate ? 0.08 : 1;
    if (root.current) root.current.rotation.y += (rotation - root.current.rotation.y) * k;
    if (epi.current) epi.current.position.y += (explode * 0.38 - epi.current.position.y) * k;
    if (sub.current) sub.current.position.y += (-explode * 0.38 - sub.current.position.y) * k;
  });

  const tones: ("dark" | "light")[] =
    state.hairTone === "light" ? ["light", "light", "light", "light"] : state.hairTone === "mixed" ? ["dark", "light", "dark", "light"] : ["dark", "dark", "dark", "dark"];
  const phases: Phase[] = state.phases ? ["anagen", "catagen", "anagen", "telogen"] : ["anagen", "anagen", "anagen", "anagen"];

  return (
    <group ref={root}>
      <group ref={epi}>
        <Epidermis scar={state.scar ?? 0} melanin={state.melaninEpi ?? 0.35} />
      </group>
      <group>
        <Dermis scar={state.scar ?? 0} collagen={state.collagen ?? 0.7} dermalMelanin={state.melaninDermal ?? 0} />
        {FOLLICLES.map((x, i) => (
          <Follicle key={i} x={x} index={i} phase={phases[i]} tone={tones[i]} state={state} pulseT={pulseT} />
        ))}
        <SweatGland />
        <Vessels />
      </group>
      <group ref={sub}>
        <Subcutis />
      </group>
      <PulseWave pulseT={pulseT} active={!!state.pulse} animate={animate} />
    </group>
  );
}

function ResetCamera({ resetKey, controls }: { resetKey: number; controls: React.RefObject<OrbitControlsImpl | null> }) {
  const { camera } = useThree();
  const home = useMemo(() => new THREE.Vector3(0.5, 1.25, 4.9), []);
  const target = useMemo(() => new THREE.Vector3(0, 0, -0.4), []);
  const resetting = useRef(false);
  useEffect(() => {
    if (resetKey > 0) resetting.current = true;
  }, [resetKey]);
  useFrame(() => {
    if (!resetting.current) return;
    camera.position.lerp(home, 0.12);
    controls.current?.target.lerp(target, 0.12);
    controls.current?.update();
    if (camera.position.distanceTo(home) < 0.01) resetting.current = false;
  });
  return null;
}

export interface SkinSceneProps {
  state: SkinState;
  selected: StructureId | null;
  onSelect: (id: StructureId) => void;
  labelIds: StructureId[];
  showLabels: boolean;
  rotation: number;
  resetKey: number;
  active: boolean;
  animate: boolean;
  allowDrag: boolean;
}

export default function SkinScene(p: SkinSceneProps) {
  const controls = useRef<OrbitControlsImpl>(null);
  const ctx = useMemo<Ctx>(
    () => ({ selected: p.selected, select: p.onSelect, labels: new Set(p.labelIds), showLabels: p.showLabels }),
    [p.selected, p.onSelect, p.labelIds, p.showLabels],
  );
  return (
    <Canvas
      dpr={[1, 1.75]}
      frameloop={p.active ? "always" : "never"}
      camera={{ position: [0.5, 1.25, 4.9], fov: 38, near: 0.1, far: 30 }}
      gl={{ antialias: true, alpha: true }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
      }}
      onPointerMissed={() => (document.body.style.cursor = "")}
    >
      <SceneCtx.Provider value={ctx}>
        <hemisphereLight args={["#FFF8F4", "#E8D2CE", 0.9]} />
        <directionalLight position={[2.5, 4, 5]} intensity={1.8} color="#FFF4EC" />
        <directionalLight position={[-4, 2, 2]} intensity={0.6} color="#F3C9D3" />
        <pointLight position={[0, 2.5, 2]} intensity={6} distance={7} color="#FFFFFF" />
        <group position={[0, 0, 0]}>
          <Model state={p.state} rotation={p.rotation} animate={p.animate} />
        </group>
        <OrbitControls
          ref={controls}
          enabled={p.allowDrag}
          enablePan={false}
          enableZoom={false}
          enableDamping
          dampingFactor={0.08}
          target={[0, 0, -0.4]}
          minAzimuthAngle={-0.75}
          maxAzimuthAngle={0.75}
          minPolarAngle={0.95}
          maxPolarAngle={1.75}
        />
        <ResetCamera resetKey={p.resetKey} controls={controls} />
      </SceneCtx.Provider>
    </Canvas>
  );
}
