import type { Metadata } from "next";
import { site } from "@/content/site";

export function pageMeta({ title, description, path }: { title: string; description: string; path: string }): Metadata {
  return {
    title,
    description,
    alternates: { canonical: path },
    openGraph: { title: `${title} | ${site.name}`, description, url: path, siteName: site.name, locale: "en_IN", type: "website" },
    twitter: { card: "summary_large_image", title: `${title} | ${site.name}`, description },
  };
}

/** Structured data limited to facts from the supplied content sheet. */
export function clinicJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "MedicalClinic",
    name: site.name,
    url: site.url,
    logo: `${site.url}/brand/luxe-clinique-logo.png`,
    email: site.email,
    telephone: site.phones[0].tel,
    address: {
      "@type": "PostalAddress",
      streetAddress: site.address.line1,
      addressLocality: `${site.address.locality}, ${site.address.city}`,
      postalCode: site.address.postalCode,
      addressRegion: site.address.region,
      addressCountry: site.address.country,
    },
  };
}

export function JsonLd({ data }: { data: object }) {
  return { __html: JSON.stringify(data).replace(/</g, "\\u003c") };
}
