// Server-only: uses the filesystem at build/render time.
import fs from "node:fs";
import path from "node:path";

const EXT = ["webp", "avif", "jpg", "jpeg", "png"];
const dir = path.join(process.cwd(), "public", "images");

/** Returns the public URL of a supplied photo for an asset slot, or null if none has been added yet. */
export function resolveImage(id: string): string | null {
  for (const ext of EXT) {
    if (fs.existsSync(path.join(dir, `${id}.${ext}`))) return `/images/${id}.${ext}`;
  }
  return null;
}
