import Link from "next/link";
import { notFound } from "next/navigation";
import Educational3DModule from "@/components/education/Educational3DModule";
import GlassTreatmentCard from "@/components/ui/GlassTreatmentCard";
import { ConsultationCTA, PageHero } from "@/components/ui/blocks";
import { modules } from "@/content/education";
import { publishedTreatments, type ModuleId } from "@/content/treatments";
import { toCard } from "@/lib/cards";
import { pageMeta } from "@/lib/seo";

export function generateStaticParams() {
  return Object.keys(modules).map((id) => ({ id }));
}
export const dynamicParams = false;

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const m = modules[id as ModuleId];
  return m ? pageMeta({ title: `${m.title} — Interactive 3D Guide`, description: m.intro.slice(0, 158), path: `/learn/models/${id}` }) : {};
}

export default async function ModelPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const m = modules[id as ModuleId];
  if (!m) notFound();
  const related = publishedTreatments.filter((t) => t.module === m.id).slice(0, 6).map(toCard);
  return (
    <>
      <PageHero eyebrow={m.eyebrow} title={m.title} crumbs={[{ href: "/learn", label: "Learn" }, { href: `/learn/models/${id}`, label: m.title }]} />
      <section className="container-luxe pb-16">
        <Educational3DModule moduleId={m.id} />
        {related.length > 0 && (
          <>
            <h2 className="font-display mt-16 text-[1.9rem]">Treatments that use this guide</h2>
            <ul className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((r) => (
                <li key={r.slug}>
                  <GlassTreatmentCard t={r} />
                </li>
              ))}
            </ul>
          </>
        )}
        <p className="mt-10 text-[14px] text-muted">
          <Link href="/learn" className="font-semibold text-burgundy hover:underline">← All educational resources</Link>
        </p>
      </section>
      <ConsultationCTA />
    </>
  );
}
