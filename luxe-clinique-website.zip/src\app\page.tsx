import Link from "next/link";
import { ArrowRight, BookOpen, Scale, Stethoscope, UserRound, Zap, Syringe, Sparkles, Palette, Leaf, HeartPulse, Scissors } from "lucide-react";
import HomeHero from "@/components/home/HomeHero";
import ConsultationProcess from "@/components/home/ConsultationProcess";
import { LaserEducationScene } from "@/components/education/named-modules";
import { AnimatedSection, MaskReveal, Reveal } from "@/components/motion/AnimatedSection";
import ClinicImage from "@/components/media/ClinicImage";
import GlassTreatmentCard from "@/components/ui/GlassTreatmentCard";
import Accordion from "@/components/ui/Accordion";
import { ConsultationCTA, SectionHeading } from "@/components/ui/blocks";
import { categories, featuredSlugs, publishedTreatments, type CategoryId } from "@/content/treatments";
import { articles } from "@/content/articles";
import { generalFaqs } from "@/content/faqs";
import { toCard } from "@/lib/cards";
import { pageMeta } from "@/lib/seo";

export const metadata = {
  ...pageMeta({
    title: "Skin, Hair & Laser Care in Preet Vihar, New Delhi",
    description:
      "Explore skin, hair, laser and aesthetic treatments through clear education and individual consultation at The LUXE Clinique, Preet Vihar, New Delhi.",
    path: "/",
  }),
  title: { absolute: "The LUXE Clinique | Skin, Hair & Laser Care in Preet Vihar, New Delhi" },
};

const catIcons: Record<CategoryId, typeof Zap> = {
  laser: Zap,
  injectables: Syringe,
  skin: Sparkles,
  pigmentation: Palette,
  hair: Leaf,
  dermatology: HeartPulse,
  procedures: Scissors,
};

const principles = [
  { icon: Stethoscope, title: "Assessment first", body: "Options are discussed only after your concern, history and skin have been assessed." },
  { icon: BookOpen, title: "Balanced information", body: "How a treatment works, its benefits, risks, limitations and alternatives — explained clearly." },
  { icon: UserRound, title: "Individual plans", body: "Plans reflect your skin, goals and circumstances, and some people are advised not to treat." },
  { icon: Scale, title: "Your decision", body: "Time to consider, ask questions and decide, without pressure." },
];

export default function Home() {
  const featured = featuredSlugs.map((s) => publishedTreatments.find((t) => t.slug === s)!).filter(Boolean);
  const counts = publishedTreatments.reduce<Record<string, number>>((a, t) => ((a[t.category] = (a[t.category] ?? 0) + 1), a), {});

  return (
    <>
      <HomeHero />

      {/* ── Clinic introduction ── */}
      <section id="introduction" className="section container-luxe scroll-mt-24" aria-labelledby="intro-title">
        <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-16">
          <MaskReveal className="relative lg:col-span-5">
            <ClinicImage id="home-clinic-interior" className="aspect-[4/5] w-full rounded-[28px]" priority />
            <div className="glass glass-strong absolute -bottom-6 right-4 max-w-[15rem] p-4 sm:right-[-1.5rem]">
              <p className="eyebrow !text-[0.62rem]">Location</p>
              <p className="mt-1.5 text-[14px] leading-snug text-charcoal">103, Rajdhani Enclave, Preet Vihar, New Delhi 110092</p>
            </div>
          </MaskReveal>
          <div className="lg:col-span-7">
            <SectionHeading
              id="intro-title"
              eyebrow="The LUXE Clinique"
              title="Skin, hair and aesthetic care, explained before it's offered."
              intro="The clinic provides consultations about skin, hair and aesthetic concerns. Treatment options depend on a clinical assessment and are discussed openly — including what a treatment can and cannot do."
            />
            <AnimatedSection as="ul" className="mt-10 grid gap-4 sm:grid-cols-2">
              {principles.map(({ icon: Icon, title, body }) => (
                <Reveal as="li" key={title} className="glass p-5">
                  <Icon size={22} strokeWidth={1.6} className="text-burgundy" aria-hidden />
                  <h3 className="mt-3 font-semibold text-charcoal">{title}</h3>
                  <p className="mt-1.5 text-[14.5px] leading-relaxed text-muted">{body}</p>
                </Reveal>
              ))}
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* ── Treatment categories ── */}
      <section className="section relative overflow-hidden bg-gradient-to-b from-ivory via-blush/40 to-ivory" aria-labelledby="cat-title">
        <div className="container-luxe">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionHeading id="cat-title" eyebrow="Treatment categories" title="Explore by area of care" />
            <Link href="/treatments" className="btn btn-glass">
              View all treatments <ArrowRight size={16} aria-hidden />
            </Link>
          </div>
          <AnimatedSection as="ul" className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {(Object.keys(categories) as CategoryId[]).map((c, i) => {
              const Icon = catIcons[c];
              return (
                <Reveal as="li" key={c} className={i === 0 ? "sm:col-span-2 lg:col-span-1 lg:row-span-2" : ""}>
                  <Link
                    href={`/treatments?category=${c}`}
                    className={`group flex h-full flex-col justify-between gap-6 p-6 transition-transform duration-500 hover:-translate-y-1 ${i === 0 ? "glass-burgundy glass-sheen" : "glass glass-sheen"}`}
                  >
                    <span className={`grid h-12 w-12 place-items-center rounded-full ${i === 0 ? "bg-white/15 text-white" : "bg-burgundy/10 text-burgundy"}`}>
                      <Icon size={22} strokeWidth={1.6} aria-hidden />
                    </span>
                    <div>
                      <h3 className={`font-display text-[1.35rem] leading-snug ${i === 0 ? "text-white" : "text-charcoal"}`}>{categories[c].label}</h3>
                      <p className={`mt-2 text-[14px] leading-relaxed ${i === 0 ? "text-white/80" : "text-muted"}`}>{categories[c].blurb}</p>
                      <p className={`mt-4 flex items-center gap-1.5 text-[13px] font-semibold ${i === 0 ? "text-white" : "text-burgundy"}`}>
                        {counts[c] ?? 0} topics <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" aria-hidden />
                      </p>
                    </div>
                  </Link>
                </Reveal>
              );
            })}
          </AnimatedSection>
        </div>
      </section>

      {/* ── 3D education feature ── */}
      <section className="section container-luxe" aria-label="Interactive education">
        <SectionHeading
          eyebrow="Interactive education"
          title="See the principle before you consider the procedure."
          intro="Our 3D guides explain how skin works and the general idea behind common treatments. Step through the laser hair reduction sequence below."
        />
        <div className="mt-10">
          <LaserEducationScene headingLevel={3} />
        </div>
      </section>

      {/* ── Featured treatments ── */}
      <section className="section !pt-0 container-luxe" aria-labelledby="feat-title">
        <SectionHeading id="feat-title" eyebrow="Treatment guides" title="Frequently explored treatments" />
        <AnimatedSection as="ul" className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((t, i) => (
            <Reveal as="li" key={t.slug}>
              <GlassTreatmentCard t={toCard(t)} priority={i < 3} />
            </Reveal>
          ))}
        </AnimatedSection>
      </section>

      {/* ── Consultation process ── */}
      <section className="section relative overflow-hidden bg-gradient-to-b from-ivory to-blush/50" aria-labelledby="process-title">
        <div className="container-luxe">
          <div className="grid items-end gap-8 lg:grid-cols-2">
            <SectionHeading id="process-title" eyebrow="Consultation process" title="Four steps, with your informed decision at the centre." />
            <MaskReveal className="hidden lg:block">
              <ClinicImage id="home-consultation" className="aspect-[3/2] w-full rounded-[28px]" />
            </MaskReveal>
          </div>
          <ConsultationProcess />
        </div>
      </section>

      {/* ── Educational content ── */}
      <section className="section container-luxe" aria-labelledby="learn-title">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading id="learn-title" eyebrow="Learn" title="Educational guides" intro="Balanced explanations of common topics, including limitations and risks." />
          <Link href="/learn" className="btn btn-glass">
            All guides <ArrowRight size={16} aria-hidden />
          </Link>
        </div>
        <AnimatedSection as="ul" className="mt-10 grid gap-5 md:grid-cols-3">
          {articles.slice(0, 3).map((a) => (
            <Reveal as="li" key={a.slug}>
              <Link href={`/learn/${a.slug}`} className="glass glass-sheen group flex h-full flex-col p-6 transition-transform duration-500 hover:-translate-y-1">
                <span className="eyebrow !text-[0.64rem]">{a.module ? "Guide · includes 3D model" : "Guide"}</span>
                <h3 className="font-display mt-3 text-[1.3rem] leading-snug text-charcoal">{a.title}</h3>
                <p className="mt-2 text-[14px] leading-relaxed text-muted">{a.description}</p>
                <span className="mt-auto flex items-center gap-1.5 pt-5 text-[13.5px] font-semibold text-burgundy">
                  Read guide <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" aria-hidden />
                </span>
              </Link>
            </Reveal>
          ))}
        </AnimatedSection>
      </section>

      {/* ── FAQ ── */}
      <section className="section !pt-0 container-luxe" aria-labelledby="faq-title">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <SectionHeading id="faq-title" eyebrow="Questions" title="Frequently asked questions" />
          </div>
          <div className="lg:col-span-8">
            <Accordion items={generalFaqs} defaultOpen={0} />
          </div>
        </div>
      </section>

      <ConsultationCTA />
    </>
  );
}
