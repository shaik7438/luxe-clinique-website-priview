"use client";

/**
 * Signature hero: a stylised, procedurally-modelled laser hair reduction
 * treatment room. Everything is built from primitives (no external assets),
 * so it loads instantly and degrades gracefully. When a production GLB is
 * supplied via NEXT_PUBLIC_HERO_GLB, it is rendered instead.
 *
 * Art direction: "porcelain gallery" — soft, matte, sculptural figures in an
 * ivory room with burgundy accents. The patient wears protective eye shields,
 * the clinician wears laser safety glasses, and the handpiece is in contact
 * with the skin. There is deliberately no visible "beam".
 */

import { Suspense, useMemo, useRef } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { ContactShadows, Environment, Lightformer, RoundedBox, useGLTF } from "@react-three/drei";
import * as THREE from "three";
import { Limb, Tube } from "./primitives";

const C = {
  burgundy: "#7B1734",
  ivory: "#FAF7F5",
  wall: "#F3EBE7",
  floor: "#EADFD9",
  blush: "#EBD5D6",
  rose: "#B87A89",
  patientSkin: "#D2A084",
  clinicianSkin: "#C08A6B",
  hair: "#2B1E1A",
  coat: "#FFFFFF",
  scrubs: "#3B3539",
  glove: "#D9D3EC",
  sheet: "#F3E3E3",
};

/* ───────────── Materials (memoised per scene) ───────────── */
function useMaterials() {
  return useMemo(() => {
    const m = (p: THREE.MeshPhysicalMaterialParameters) => new THREE.MeshPhysicalMaterial(p);
    return {
      wall: m({ color: C.wall, roughness: 0.95 }),
      floor: m({ color: C.floor, roughness: 0.6, clearcoat: 0.25, clearcoatRoughness: 0.6 }),
      blush: m({ color: C.blush, roughness: 0.9 }),
      burgundy: m({ color: C.burgundy, roughness: 0.45, clearcoat: 0.4 }),
      burgundyMatte: m({ color: C.burgundy, roughness: 0.8 }),
      leather: m({ color: "#FBF8F6", roughness: 0.42, clearcoat: 0.5, clearcoatRoughness: 0.35, sheen: 0.4 }),
      plinth: m({ color: "#E4D9D3", roughness: 0.6 }),
      skinP: m({ color: C.patientSkin, roughness: 0.62, sheen: 0.6, sheenColor: new THREE.Color("#f3c3ad"), sheenRoughness: 0.5 }),
      skinC: m({ color: C.clinicianSkin, roughness: 0.62, sheen: 0.6, sheenColor: new THREE.Color("#e9b49a"), sheenRoughness: 0.5 }),
      hair: m({ color: C.hair, roughness: 0.55, sheen: 0.8, sheenColor: new THREE.Color("#5a4038") }),
      coat: m({ color: C.coat, roughness: 0.78, sheen: 0.4, sheenColor: new THREE.Color("#ffffff") }),
      scrubs: m({ color: C.scrubs, roughness: 0.85 }),
      glove: m({ color: C.glove, roughness: 0.4, clearcoat: 0.2 }),
      sheet: m({ color: C.sheet, roughness: 0.92, sheen: 0.5, sheenColor: new THREE.Color("#fff") }),
      sheetFold: m({ color: "#FBF4F3", roughness: 0.92 }),
      shields: m({ color: "#1F1C22", roughness: 0.25, clearcoat: 1, metalness: 0.1 }),
      safetyGlass: m({ color: "#2F6B57", roughness: 0.05, transmission: 0.6, thickness: 0.02, transparent: true, opacity: 0.85 }),
      device: m({ color: "#FDFBFA", roughness: 0.28, clearcoat: 0.8, clearcoatRoughness: 0.15 }),
      deviceDark: m({ color: "#2C272B", roughness: 0.5 }),
      sapphire: m({ color: "#DDEBF2", roughness: 0.02, transmission: 0.9, thickness: 0.05, transparent: true, opacity: 0.9 }),
      chrome: m({ color: "#D8D2D0", metalness: 0.9, roughness: 0.25 }),
      plant: m({ color: "#7E8F76", roughness: 0.7 }),
      pot: m({ color: "#E9DFD9", roughness: 0.7 }),
      mask: m({ color: "#D5E3EC", roughness: 0.9 }),
    };
  }, []);
}
type Mats = ReturnType<typeof useMaterials>;

/* ───────────── Room ───────────── */
function Room({ m, detailed }: { m: Mats; detailed: boolean }) {
  const arch = useMemo(() => {
    const s = new THREE.Shape();
    const w = 0.8, h = 2.2;
    s.moveTo(-w, 0);
    s.lineTo(-w, h);
    s.absarc(0, h, w, Math.PI, 0, true);
    s.lineTo(w, 0);
    s.lineTo(-w, 0);
    return new THREE.ExtrudeGeometry(s, { depth: 0.04, bevelEnabled: false });
  }, []);
  const archLine = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    const w = 0.92, h = 2.2;
    pts.push(new THREE.Vector3(-w, 0, 0), new THREE.Vector3(-w, h, 0));
    for (let i = 0; i <= 40; i++) {
      const a = Math.PI - (i / 40) * Math.PI;
      pts.push(new THREE.Vector3(Math.cos(a) * w, h + Math.sin(a) * w, 0));
    }
    pts.push(new THREE.Vector3(w, 0, 0));
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts, false, "catmullrom", 0.02), 200, 0.012, 6, false);
  }, []);

  return (
    <group>
      <mesh rotation-x={-Math.PI / 2} receiveShadow material={m.floor}>
        <planeGeometry args={[14, 10]} />
      </mesh>
      <mesh position={[0, 2.5, -2.2]} receiveShadow material={m.wall}>
        <planeGeometry args={[14, 5]} />
      </mesh>
      <mesh position={[-3.2, 2.5, 0]} rotation-y={Math.PI / 2} receiveShadow material={m.wall}>
        <planeGeometry args={[10, 5]} />
      </mesh>
      {/* Skirting */}
      <mesh position={[0, 0.06, -2.18]} material={m.plinth}>
        <boxGeometry args={[14, 0.12, 0.04]} />
      </mesh>

      {/* Arched niche with burgundy outline */}
      <mesh geometry={arch} position={[-1.3, 0, -2.19]} material={m.blush} receiveShadow />
      <mesh geometry={archLine} position={[-1.3, 0, -2.14]} material={m.burgundy} />

      {/* Fluted wall panel */}
      {detailed &&
        Array.from({ length: 16 }).map((_, i) => (
          <RoundedBox key={i} args={[0.075, 2.6, 0.05]} radius={0.03} position={[0.75 + i * 0.1, 1.3, -2.17]} material={m.device} receiveShadow />
        ))}

      {/* Cabinet with folded towels */}
      <group position={[-2.35, 0, -1.65]}>
        <RoundedBox args={[1.1, 0.9, 0.5]} radius={0.04} position={[0, 0.45, 0]} material={m.device} castShadow receiveShadow />
        <mesh position={[0, 0.62, 0.252]} material={m.burgundy}>
          <boxGeometry args={[0.6, 0.012, 0.01]} />
        </mesh>
        <RoundedBox args={[0.38, 0.07, 0.28]} radius={0.03} position={[-0.25, 0.94, 0]} material={m.coat} castShadow />
        <RoundedBox args={[0.38, 0.07, 0.28]} radius={0.03} position={[-0.25, 1.01, 0]} material={m.blush} castShadow />
        <mesh position={[0.28, 1.02, 0]} material={m.pot} castShadow>
          <cylinderGeometry args={[0.07, 0.06, 0.24, 24]} />
        </mesh>
      </group>

      {/* Plant */}
      {detailed && (
        <group position={[-2.75, 0, -0.9]}>
          <mesh position={[0, 0.25, 0]} material={m.pot} castShadow>
            <cylinderGeometry args={[0.2, 0.16, 0.5, 32]} />
          </mesh>
          {Array.from({ length: 9 }).map((_, i) => {
            const a = (i / 9) * Math.PI * 2;
            const tilt = 0.35 + (i % 3) * 0.12;
            return (
              <mesh
                key={i}
                position={[Math.cos(a) * 0.12, 0.85 + (i % 3) * 0.08, Math.sin(a) * 0.12]}
                rotation={[Math.sin(a) * tilt, a, -Math.cos(a) * tilt]}
                scale={[0.07, 0.42, 0.025]}
                material={m.plant}
                castShadow
              >
                <sphereGeometry args={[1, 16, 12]} />
              </mesh>
            );
          })}
        </group>
      )}

      {/* Pendant lights */}
      {[-0.35, 0.75].map((x) => (
        <group key={x} position={[x, 0, -0.1]}>
          <mesh position={[0, 3.35, 0]} material={m.deviceDark}>
            <cylinderGeometry args={[0.006, 0.006, 1.1, 6]} />
          </mesh>
          <mesh position={[0, 2.78, 0]} material={m.burgundy}>
            <sphereGeometry args={[0.16, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
          </mesh>
          <mesh position={[0, 2.76, 0]}>
            <sphereGeometry args={[0.07, 16, 16]} />
            <meshBasicMaterial color="#FFF3E6" toneMapped={false} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

/* ───────────── Treatment bed ───────────── */
function Bed({ m }: { m: Mats }) {
  return (
    <group>
      <RoundedBox args={[1.25, 0.46, 0.46]} radius={0.06} position={[0, 0.27, 0]} material={m.plinth} castShadow receiveShadow />
      <RoundedBox args={[1.45, 0.06, 0.6]} radius={0.025} position={[0, 0.03, 0]} material={m.deviceDark} receiveShadow />
      <RoundedBox args={[2.05, 0.15, 0.74]} radius={0.06} position={[0, 0.6, 0]} material={m.leather} castShadow receiveShadow />
      <mesh position={[0, 0.535, 0]} material={m.burgundy}>
        <boxGeometry args={[2.0, 0.02, 0.75]} />
      </mesh>
      {/* Pillow */}
      <RoundedBox args={[0.34, 0.08, 0.44]} radius={0.04} position={[-0.83, 0.71, 0]} material={m.coat} castShadow receiveShadow />
    </group>
  );
}

/* ───────────── Patient (supine, head at −x) ───────────── */
function Patient({ m }: { m: Mats }) {
  return (
    <group>
      {/* Head, face up */}
      <mesh position={[-0.82, 0.84, 0]} scale={[1, 0.92, 0.86]} material={m.skinP} castShadow>
        <sphereGeometry args={[0.105, 32, 24]} />
      </mesh>
      <mesh position={[-0.88, 0.82, 0]} scale={[1.02, 0.82, 1.02]} material={m.hair} castShadow>
        <sphereGeometry args={[0.113, 32, 24]} />
      </mesh>
      <mesh position={[-0.995, 0.77, 0]} material={m.hair} castShadow>
        <sphereGeometry args={[0.055, 16, 12]} />
      </mesh>
      <mesh position={[-0.765, 0.925, 0]} material={m.skinP}>
        <sphereGeometry args={[0.02, 12, 10]} />
      </mesh>
      {/* Protective eye shields with strap */}
      {[-0.042, 0.042].map((z) => (
        <mesh key={z} position={[-0.83, 0.925, z]} scale={[0.7, 0.35, 1]} material={m.shields}>
          <sphereGeometry args={[0.032, 20, 14]} />
        </mesh>
      ))}
      <mesh position={[-0.84, 0.84, 0]} rotation-y={Math.PI / 2} material={m.shields}>
        <torusGeometry args={[0.093, 0.006, 6, 48]} />
      </mesh>
      {/* Neck */}
      <Limb from={[-0.74, 0.8, 0]} to={[-0.66, 0.79, 0]} radius={0.045}>
        <primitive object={m.skinP} attach="material" />
      </Limb>
      {/* Torso volume under sheet */}
      <Limb from={[-0.56, 0.75, 0]} to={[0.1, 0.74, 0]} radius={0.14}>
        <primitive object={m.sheet} attach="material" />
      </Limb>
      {/* Draped sheet */}
      <RoundedBox args={[1.22, 0.2, 0.56]} radius={0.09} smoothness={6} position={[-0.04, 0.76, 0]} material={m.sheet} castShadow receiveShadow />
      <RoundedBox args={[0.1, 0.215, 0.575]} radius={0.05} position={[0.53, 0.76, 0]} material={m.sheetFold} castShadow />
      {/* Exposed lower legs — treatment area on the near (+z) leg */}
      {[-0.075, 0.075].map((z) => (
        <group key={z}>
          <Limb from={[0.55, 0.755, z]} to={[1.0, 0.74, z * 0.92]} radius={0.052}>
            <primitive object={m.skinP} attach="material" />
          </Limb>
          <Limb from={[1.02, 0.74, z * 0.92]} to={[1.05, 0.83, z * 0.95]} radius={0.04}>
            <primitive object={m.skinP} attach="material" />
          </Limb>
        </group>
      ))}
    </group>
  );
}

/* ───────────── Clinician (standing at +z, facing the bed) ───────────── */
function Clinician({ m }: { m: Mats }) {
  const shoulderR: [number, number, number] = [0.93, 1.37, 0.78];
  const shoulderL: [number, number, number] = [0.6, 1.37, 0.78];
  const handR: [number, number, number] = [0.86, 0.98, 0.26];
  const handL: [number, number, number] = [0.66, 0.86, 0.15];
  return (
    <group>
      {/* Legs and shoes */}
      {[0.68, 0.85].map((x) => (
        <group key={x}>
          <Limb from={[x, 0.07, 0.86]} to={[x, 0.78, 0.86]} radius={0.062}>
            <primitive object={m.scrubs} attach="material" />
          </Limb>
          <RoundedBox args={[0.1, 0.07, 0.2]} radius={0.03} position={[x, 0.035, 0.82]} material={m.coat} castShadow />
        </group>
      ))}
      {/* Coat body, leaning slightly toward the bed */}
      <group position={[0.765, 0, 0.83]} rotation-x={-0.16}>
        <mesh position={[0, 0.72, 0]} material={m.coat} castShadow receiveShadow>
          <cylinderGeometry args={[0.215, 0.25, 0.34, 32]} />
        </mesh>
        <mesh position={[0, 1.1, 0]} material={m.coat} castShadow receiveShadow>
          <cylinderGeometry args={[0.165, 0.215, 0.46, 32]} />
        </mesh>
        <mesh position={[0, 1.34, 0]} material={m.coat} castShadow>
          <sphereGeometry args={[0.165, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
        </mesh>
        {/* Burgundy collar piping and pocket */}
        <mesh position={[0, 1.4, 0]} rotation-x={Math.PI / 2} material={m.burgundy}>
          <torusGeometry args={[0.07, 0.012, 8, 32]} />
        </mesh>
        <mesh position={[0.09, 1.16, -0.19]} rotation-x={0.12} material={m.burgundy}>
          <boxGeometry args={[0.07, 0.008, 0.01]} />
        </mesh>
        <Limb from={[0, 1.4, 0]} to={[0, 1.47, 0]} radius={0.045}>
          <primitive object={m.skinC} attach="material" />
        </Limb>
      </group>
      {/* Head */}
      <group position={[0.765, 1.6, 0.68]}>
        <mesh scale={[0.92, 1.05, 0.95]} material={m.skinC} castShadow>
          <sphereGeometry args={[0.1, 32, 24]} />
        </mesh>
        <mesh position={[0, 0.025, 0.03]} scale={[1, 0.95, 0.98]} material={m.hair} castShadow>
          <sphereGeometry args={[0.104, 32, 24, 0, Math.PI * 2, 0, Math.PI * 0.62]} />
        </mesh>
        <mesh position={[0, 0.03, 0.12]} material={m.hair} castShadow>
          <sphereGeometry args={[0.05, 16, 12]} />
        </mesh>
        {/* Laser safety glasses */}
        <RoundedBox args={[0.17, 0.045, 0.03]} radius={0.014} position={[0, 0.012, -0.085]} material={m.safetyGlass} />
        {/* Face mask */}
        <RoundedBox args={[0.13, 0.065, 0.03]} radius={0.015} position={[0, -0.045, -0.08]} material={m.mask} />
      </group>
      {/* Arms */}
      <Limb from={shoulderR} to={[0.99, 1.1, 0.52]} radius={0.05}>
        <primitive object={m.coat} attach="material" />
      </Limb>
      <Limb from={[0.99, 1.1, 0.52]} to={handR} radius={0.042}>
        <primitive object={m.coat} attach="material" />
      </Limb>
      <mesh position={handR} material={m.glove} castShadow>
        <sphereGeometry args={[0.042, 16, 12]} />
      </mesh>
      <Limb from={shoulderL} to={[0.53, 1.08, 0.56]} radius={0.05}>
        <primitive object={m.coat} attach="material" />
      </Limb>
      <Limb from={[0.53, 1.08, 0.56]} to={handL} radius={0.042}>
        <primitive object={m.coat} attach="material" />
      </Limb>
      <mesh position={handL} scale={[1.2, 0.7, 1]} material={m.glove} castShadow>
        <sphereGeometry args={[0.042, 16, 12]} />
      </mesh>
    </group>
  );
}

/* ───────────── Handpiece, cable and laser console ───────────── */
function Handpiece({ m, animate }: { m: Mats; animate: boolean }) {
  const led = useRef<THREE.MeshStandardMaterial>(null);
  useFrame(({ clock }) => {
    if (!led.current) return;
    const t = clock.getElapsedTime();
    led.current.emissiveIntensity = animate ? 0.8 + Math.max(0, Math.sin(t * 2.4)) * 1.6 : 1.2;
  });
  return (
    <group>
      <Limb from={[0.88, 1.02, 0.29]} to={[0.8, 0.885, 0.11]} radius={0.028}>
        <primitive object={m.device} attach="material" />
      </Limb>
      <mesh position={[0.86, 0.99, 0.25]} rotation={[0.9, 0, 0.3]} material={m.burgundy}>
        <torusGeometry args={[0.029, 0.006, 8, 24]} />
      </mesh>
      {/* Treatment head with cooled sapphire window in contact with skin */}
      <group position={[0.79, 0.848, 0.085]} rotation={[0.35, 0.3, 0]}>
        <RoundedBox args={[0.075, 0.04, 0.06]} radius={0.012} material={m.device} castShadow />
        <mesh position={[0, -0.022, 0]} material={m.sapphire}>
          <boxGeometry args={[0.05, 0.006, 0.036]} />
        </mesh>
        <mesh position={[0, 0.022, 0.015]}>
          <sphereGeometry args={[0.006, 10, 8]} />
          <meshStandardMaterial ref={led} color={C.burgundy} emissive="#E2526F" emissiveIntensity={1.2} />
        </mesh>
      </group>
      <Tube
        points={[
          [0.9, 1.05, 0.33],
          [0.98, 0.95, 0.5],
          [1.12, 0.55, 0.62],
          [1.35, 0.45, 0.45],
          [1.48, 0.8, 0.28],
        ]}
        radius={0.011}
        castShadow
      >
        <primitive object={m.deviceDark} attach="material" />
      </Tube>
    </group>
  );
}

function Console({ m }: { m: Mats }) {
  const screen = useMemo(() => {
    const cvs = document.createElement("canvas");
    cvs.width = 512;
    cvs.height = 320;
    const g = cvs.getContext("2d")!;
    const grd = g.createLinearGradient(0, 0, 512, 320);
    grd.addColorStop(0, "#2a1620");
    grd.addColorStop(1, "#4a1426");
    g.fillStyle = grd;
    g.fillRect(0, 0, 512, 320);
    g.strokeStyle = "rgba(255,255,255,0.18)";
    g.lineWidth = 2;
    for (let i = 0; i < 3; i++) {
      g.beginPath();
      g.arc(130, 165, 50 + i * 26, 0, Math.PI * 2);
      g.stroke();
    }
    g.strokeStyle = "#E7A3B4";
    g.lineWidth = 8;
    g.beginPath();
    g.arc(130, 165, 76, -Math.PI / 2, Math.PI * 0.9);
    g.stroke();
    g.fillStyle = "rgba(255,255,255,0.9)";
    g.font = "600 26px Inter, sans-serif";
    g.fillText("Skin type", 250, 110);
    g.fillText("Cooling", 250, 180);
    g.fillText("Area", 250, 250);
    g.fillStyle = "rgba(255,255,255,0.35)";
    [126, 196, 266].forEach((y) => g.fillRect(250, y, 210, 6));
    g.fillStyle = "#E7A3B4";
    [140, 180, 110].forEach((w, i) => g.fillRect(250, 126 + i * 70, w, 6));
    const tex = new THREE.CanvasTexture(cvs);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    return tex;
  }, []);
  return (
    <group position={[1.62, 0, -0.42]} rotation-y={-0.55}>
      <RoundedBox args={[0.52, 0.07, 0.52]} radius={0.025} position={[0, 0.1, 0]} material={m.deviceDark} castShadow />
      {[[-0.2, -0.2], [0.2, -0.2], [-0.2, 0.2], [0.2, 0.2]].map(([x, z]) => (
        <mesh key={`${x}${z}`} position={[x, 0.04, z]} rotation-z={Math.PI / 2} material={m.deviceDark}>
          <cylinderGeometry args={[0.04, 0.04, 0.03, 16]} />
        </mesh>
      ))}
      <RoundedBox args={[0.44, 0.86, 0.42]} radius={0.07} smoothness={6} position={[0, 0.56, 0]} material={m.device} castShadow receiveShadow />
      <mesh position={[0, 0.74, 0.212]} material={m.burgundy}>
        <boxGeometry args={[0.44, 0.05, 0.004]} />
      </mesh>
      <mesh position={[0.13, 0.94, 0.12]} material={m.burgundy}>
        <cylinderGeometry args={[0.025, 0.028, 0.02, 24]} />
      </mesh>
      {/* Holster */}
      <mesh position={[0.24, 0.85, -0.05]} rotation-z={-0.25} material={m.chrome}>
        <cylinderGeometry args={[0.035, 0.03, 0.12, 20]} />
      </mesh>
      {/* Screen */}
      <group position={[0, 1.13, 0.04]} rotation-x={-0.45}>
        <RoundedBox args={[0.4, 0.27, 0.035]} radius={0.015} material={m.deviceDark} castShadow />
        <mesh position={[0, 0, 0.0185]}>
          <planeGeometry args={[0.37, 0.235]} />
          <meshBasicMaterial map={screen} toneMapped={false} />
        </mesh>
      </group>
      <mesh position={[0, 1.0, 0]} material={m.chrome}>
        <cylinderGeometry args={[0.02, 0.02, 0.1, 12]} />
      </mesh>
    </group>
  );
}

/* ───────────── Optional production model ───────────── */
function ProductionModel({ url }: { url: string }) {
  const { scene } = useGLTF(url);
  return <primitive object={scene} />;
}

/* ───────────── Camera choreography ───────────── */
function CameraRig({ animate, compact }: { animate: boolean; compact: boolean }) {
  const { camera, pointer } = useThree();
  const base = useMemo(() => (compact ? new THREE.Vector3(3.3, 2.05, 3.7) : new THREE.Vector3(2.95, 1.85, 3.15)), [compact]);
  const target = useMemo(() => new THREE.Vector3(compact ? 0.35 : 0.2, 0.86, 0.05), [compact]);
  const intro = useRef(animate ? 0 : 1);
  useFrame(({ clock }, dt) => {
    const t = clock.getElapsedTime();
    intro.current = Math.min(1, intro.current + dt * 0.35);
    const e = 1 - Math.pow(1 - intro.current, 3);
    const swayX = animate ? Math.sin(t * 0.12) * 0.12 + pointer.x * 0.18 : 0;
    const swayY = animate ? Math.sin(t * 0.09) * 0.05 + pointer.y * 0.08 : 0;
    const desired = new THREE.Vector3(base.x + swayX + (1 - e) * 0.9, base.y + swayY + (1 - e) * 0.35, base.z + (1 - e) * 0.9);
    camera.position.lerp(desired, animate ? 0.06 : 1);
    camera.lookAt(target);
  });
  return null;
}

export default function HeroScene({ compact, animate, active }: { compact: boolean; animate: boolean; active: boolean }) {
  const glb = process.env.NEXT_PUBLIC_HERO_GLB;
  return (
    <Canvas
      shadows={!compact}
      dpr={compact ? [1, 1.5] : [1, 2]}
      frameloop={active ? "always" : "never"}
      camera={{ fov: compact ? 36 : 32, near: 0.1, far: 40, position: [3.6, 2.2, 4] }}
      gl={{ antialias: true, powerPreference: "high-performance", alpha: true }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.05;
      }}
      aria-hidden
    >
      <Scene compact={compact} animate={animate} glb={glb} />
    </Canvas>
  );
}

function Scene({ compact, animate, glb }: { compact: boolean; animate: boolean; glb?: string }) {
  const m = useMaterials();
  return (
    <>
      <color attach="background" args={["#F6EFEC"]} />
      <fog attach="fog" args={["#F6EFEC", 6, 13]} />
      <hemisphereLight args={["#FFF7F2", "#E3CFCB", 0.75]} />
      <directionalLight
        position={[3, 5, 3.2]}
        intensity={1.9}
        color="#FFF1E6"
        castShadow={!compact}
        shadow-mapSize={[1024, 1024]}
        shadow-camera-left={-3}
        shadow-camera-right={3}
        shadow-camera-top={3}
        shadow-camera-bottom={-3}
        shadow-bias={-0.0004}
        shadow-normalBias={0.02}
      />
      <pointLight position={[-2, 2.2, -1.2]} intensity={4} color="#E7A3B4" distance={6} />
      <pointLight position={[0.4, 2.6, 0]} intensity={2.4} color="#FFE9D6" distance={4} />
      <Environment resolution={128} frames={1}>
        <Lightformer form="rect" intensity={2.2} position={[0, 4, 2]} scale={[6, 2, 1]} color="#fff" />
        <Lightformer form="rect" intensity={1.2} position={[-4, 2, 0]} rotation-y={Math.PI / 2} scale={[4, 2, 1]} color="#F3D7DD" />
        <Lightformer form="ring" intensity={1.5} position={[3, 2, 3]} scale={1.5} color="#fff" />
      </Environment>

      {glb ? (
        <Suspense fallback={null}>
          <ProductionModel url={glb} />
        </Suspense>
      ) : (
        <>
          <Room m={m} detailed={!compact} />
          <group position={[0, 0, 0]}>
            <Bed m={m} />
            <Patient m={m} />
            {/* Clinician and handpiece are modelled on the near side, then mirrored to stand
                behind the bed so the camera sees patient, handpiece and clinician together. */}
            <group scale={[1, 1, -1]}>
              <Clinician m={m} />
              <Handpiece m={m} animate={animate} />
            </group>
            <Console m={m} />
          </group>
        </>
      )}
      <ContactShadows position={[0, 0.002, 0]} opacity={0.35} scale={8} blur={2.6} far={2.5} frames={1} color="#5C0F26" />
      <CameraRig animate={animate} compact={compact} />
    </>
  );
}
